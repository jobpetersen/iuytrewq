<?php
session_start();

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Databaseverbinding
require_once 'db_connect.php';

// Gebruikersgegevens ophalen
$stmt = $conn->prepare("SELECT * FROM gebruikers WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['error'] = "Gebruiker niet gevonden.";
    header('Location: Home.php');
    exit();
}

$pageTitle = "Mijn Profiel";
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Rijen DevOps</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="bg-top"></div>
    <nav class="navbar">
        <a href="Home.php">
            <img src="Images/logo.png" alt="Logo" class="logo">
        </a>
        <div class="nav-links">
            <a href="Home.php">Home</a>
            <a href="Contact.php">Contact</a>
            <?php include 'includes/profile_dropdown.php'; ?>
        </div>
    </nav>

    <div class="content">
        <div class="profile-container">
            <h1><i class="fas fa-user-circle"></i> Mijn Profiel</h1>
            
            <div class="profile-card">
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <div class="profile-info">
                        <h2><?php echo htmlspecialchars($user['naam'] ?? 'Gebruiker'); ?></h2>
                        <p class="email"><?php echo htmlspecialchars($user['email']); ?></p>
                        <span class="role-badge"><?php echo htmlspecialchars(ucfirst($user['rol'])); ?></span>
                    </div>
                </div>

                <div class="profile-details">
                    <div class="detail-item">
                        <span class="detail-label"><i class="fas fa-envelope"></i> E-mail</span>
                        <span class="detail-value"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    
                    <?php if (!empty($user['telefoon'])): ?>
                    <div class="detail-item">
                        <span class="detail-label"><i class="fas fa-phone"></i> Telefoon</span>
                        <span class="detail-value"><?php echo htmlspecialchars($user['telefoon']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <div class="detail-item">
                        <span class="detail-label"><i class="fas fa-user-tag"></i> Rol</span>
                        <span class="detail-value"><?php echo htmlspecialchars(ucfirst($user['rol'])); ?></span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="detail-label"><i class="fas fa-calendar-alt"></i> Lid sinds</span>
                        <span class="detail-value"><?php echo date('d-m-Y', strtotime($user['aangemaakt_op'])); ?></span>
                    </div>
                </div>

                <div class="profile-actions">
                    <a href="settings.php" class="btn btn-primary">
                        <i class="fas fa-cog"></i> Instellingen bewerken
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>
