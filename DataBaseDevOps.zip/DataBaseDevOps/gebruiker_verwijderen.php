<?php
// gebruiker_verwijderen.php
// Script om gebruikers te verwijderen

// Start de sessie
session_start();

// Controleer of de gebruiker is ingelogd en een beheerder is
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'beheerder') {
    header('Location: Home.php');
    exit;
}

// Controleer of er een ID is opgegeven
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: gebruikers_overzicht.php?error=Ongeldig gebruikers-ID');
    exit;
}

$gebruikerId = (int)$_GET['id'];

// Voorkom dat een beheerder zichzelf verwijdert
if ($gebruikerId === $_SESSION['user_id']) {
    header('Location: gebruikers_overzicht.php?error=Je kunt je eigen account niet verwijderen');
    exit;
}

require_once 'db_connect.php';

try {
    // Begin een transactie
    $conn->beginTransaction();
    
    // Verwijder eerst eventuele gerelateerde gegevens (afhankelijk van je database structuur)
    // Bijvoorbeeld: $conn->exec("DELETE FROM andere_tabel WHERE gebruiker_id = $gebruikerId");
    
    // Verwijder de gebruiker
    $stmt = $conn->prepare("DELETE FROM gebruikers WHERE id = ?");
    $stmt->execute([$gebruikerId]);
    
    // Bevestig de transactie
    $conn->commit();
    
    // Stuur terug naar het overzicht met een succesmelding
    header('Location: gebruikers_overzicht.php?success=Gebruiker succesvol verwijderd');
    exit;
    
} catch (PDOException $e) {
    // Bij een fout: rol terug en toon foutmelding
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    
    // Controleer of het een foreign key constraint fout is
    if ($e->getCode() == '23000') {
        header('Location: gebruikers_overzicht.php?error=Deze gebruiker kan niet worden verwijderd omdat er nog gerelateerde gegevens bestaan');
    } else {
        header('Location: gebruikers_overzicht.php?error=' . urlencode('Fout bij het verwijderen: ' . $e->getMessage()));
    }
    exit;
}
