<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database_devops";

try {
    // Verbind zonder database
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Verwijder bestaande database
    $stmt = $conn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");
    if ($stmt->rowCount() > 0) {
        $conn->exec("DROP DATABASE `$dbname`");
        echo "Bestaande database verwijderd.<br>";
    }
    // Maak nieuwe database
    $conn->exec("CREATE DATABASE `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "Nieuwe database aangemaakt.<br>";
    // Verbind met nieuwe database
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Maak gebruikers tabel
    $sql = "CREATE TABLE IF NOT EXISTS `gebruikers` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `naam` VARCHAR(100) NOT NULL,
        `email` VARCHAR(100) NOT NULL,
        `wachtwoord` VARCHAR(255) NOT NULL,
        `rol` ENUM('beheerder', 'klant', 'medewerker') NOT NULL DEFAULT 'klant',
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniek_email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'gebruikers' aangemaakt.<br>";
    // Voeg admin toe
    $naam = 'Beheerder';
    $email = 'admin@a.com';
    $wachtwoord = password_hash('123', PASSWORD_DEFAULT);
    $rol = 'beheerder';
    $stmt = $conn->prepare("INSERT INTO `gebruikers` (`naam`, `email`, `wachtwoord`, `rol`) VALUES (:naam, :email, :wachtwoord, :rol)");
    $stmt->bindParam(':naam', $naam);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':wachtwoord', $wachtwoord);
    $stmt->bindParam(':rol', $rol);
    if ($stmt->execute()) {
        echo "Beheerder-account aangemaakt!<br>Email: admin@a.com<br>Wachtwoord: 123<br>";
    } else {
        echo "Fout bij aanmaken beheerder-account.<br>";
    }
    // Maak uren_registratie tabel
    $sql = "CREATE TABLE IF NOT EXISTS `uren_registratie` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `medewerker` VARCHAR(100) NOT NULL,
        `project` VARCHAR(100) NOT NULL,
        `klant` VARCHAR(100) NOT NULL,
        `gewerkte_uren` DECIMAL(5,2) NOT NULL,
        `datum` DATE NOT NULL,
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'uren_registratie' aangemaakt.<br>";
    // Maak opdrachten tabel
    $sql = "CREATE TABLE IF NOT EXISTS `opdrachten` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `omschrijving` VARCHAR(255) NOT NULL,
        `deadline` DATE,
        `klant` VARCHAR(100),
        `status` ENUM('open', 'bezig', 'afgerond') NOT NULL DEFAULT 'open',
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'opdrachten' aangemaakt.<br>";
    // Maak klanten tabel
    $sql = "CREATE TABLE IF NOT EXISTS `klanten` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `naam` VARCHAR(100) NOT NULL,
        `contact` VARCHAR(100),
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'klanten' aangemaakt.<br>";
    // Maak facturen tabel
    $sql = "CREATE TABLE IF NOT EXISTS `facturen` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `factuurnummer` VARCHAR(50) NOT NULL,
        `klant` VARCHAR(100) NOT NULL,
        `bedrag` DECIMAL(10,2) NOT NULL,
        `status` ENUM('openstaand', 'betaald', 'verlopen') NOT NULL DEFAULT 'openstaand',
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniek_factuurnummer` (`factuurnummer`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'facturen' aangemaakt.<br>";
    // Maak rollen tabel
    $sql = "CREATE TABLE IF NOT EXISTS `rollen` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `rol_naam` VARCHAR(50) NOT NULL,
        `beschrijving` TEXT,
        `rechten` TEXT,
        `status` ENUM('actief', 'inactief') NOT NULL DEFAULT 'actief',
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'rollen' aangemaakt.<br>";
    // Maak orders tabel
    $sql = "CREATE TABLE IF NOT EXISTS `orders` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `order_id` VARCHAR(50) NOT NULL,
        `klant` VARCHAR(100) NOT NULL,
        `datum` DATE NOT NULL,
        `status` ENUM('in_behandeling', 'afgerond', 'geannuleerd') NOT NULL DEFAULT 'in_behandeling',
        `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniek_order_id` (`order_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'orders' aangemaakt.<br>";
    echo "<br>Database setup in het Nederlands voltooid!";
} catch(PDOException $e) {
    die("Database Fout: " . $e->getMessage());
} catch(Exception $e) {
    die("Algemene Fout: " . $e->getMessage());
}
?> 