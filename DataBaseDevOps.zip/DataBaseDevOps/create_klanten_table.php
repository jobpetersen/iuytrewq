<?php
require_once 'db_connect.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS klanten (
        id INT NOT NULL AUTO_INCREMENT,
        naam VARCHAR(100) NOT NULL,
        contact VARCHAR(100),
        aangemaakt_op TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "Tabel 'klanten' is succesvol aangemaakt!<br>";
} catch(PDOException $e) {
    echo "Database Fout: " . $e->getMessage();
}
?> 