<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
require_once 'db_connect.php';

// Haal de rol en naam van de gebruiker op
$rol = $_SESSION['rol'];
$klantnaam = $_SESSION['naam'];

// Haal urenregistraties op
if ($rol === 'klant') {
    // Controleer of de tabellen bestaan
    $tables_exist = true;
    $missing_tables = [];
    
    // Controleer of de tabellen bestaan
    $tables_to_check = ['project', 'medewerker'];
    foreach ($tables_to_check as $table) {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check->rowCount() == 0) {
            $tables_exist = false;
            $missing_tables[] = $table;
        }
    }
    
    if ($tables_exist) {
        // Als alle tabellen bestaan, voer de volledige query uit
        $stmt = $conn->prepare("
            SELECT ur.*, p.project_naam AS project, m.naam AS medewerker 
            FROM uren_registratie ur
            LEFT JOIN project p ON ur.project_id = p.id
            LEFT JOIN medewerker m ON ur.medewerker_id = m.id
            WHERE ur.klant = :klantnaam
            ORDER BY ur.datum DESC
        ");
    } else {
        // Als tabellen ontbreken, toon alleen de basisinformatie
        $stmt = $conn->prepare("
            SELECT ur.*, 
                   NULL as project, 
                   NULL as medewerker
            FROM uren_registratie ur
            WHERE ur.klant = :klantnaam
            ORDER BY ur.datum DESC
        ");
        
        // Toon een waarschuwing over ontbrekende tabellen
        echo '<div class="alert alert-warning">
                <strong>Let op:</strong> Sommige tabellen ontbreken in de database (' . implode(', ', $missing_tables) . '). 
                Hierdoor worden mogelijk niet alle gegevens getoond.
              </div>';
    }
    
    $stmt->bindParam(':klantnaam', $klantnaam);
    $stmt->execute();
    $uren = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Eerst controleren of de tabellen bestaan
    $tables_exist = true;
    $missing_tables = [];
    
    // Controleer of de tabellen bestaan
    $tables_to_check = ['uren_registratie', 'project', 'medewerker'];
    foreach ($tables_to_check as $table) {
        try {
            $check = $conn->query("SHOW TABLES LIKE '$table'");
            if ($check->rowCount() == 0) {
                $tables_exist = false;
                $missing_tables[] = $table;
            }
        } catch (PDOException $e) {
            // Als er een fout optreedt, gaan we ervan uit dat de tabel niet bestaat
            $tables_exist = false;
            $missing_tables[] = $table;
        }
    }
    
    if ($tables_exist) {
        // Als alle tabellen bestaan, voer de volledige query uit
        $stmt = $conn->query("
            SELECT ur.*, p.project_naam AS project, m.naam AS medewerker 
            FROM uren_registratie ur
            LEFT JOIN project p ON ur.project_id = p.id
            LEFT JOIN medewerker m ON ur.medewerker_id = m.id
            ORDER BY ur.datum DESC
        ");
    } else {
        // Als tabellen ontbreken, toon alleen de basisinformatie
        $stmt = $conn->query("
            SELECT ur.*, 
                   NULL as project, 
                   NULL as medewerker
            FROM uren_registratie ur
            ORDER BY ur.datum DESC
        ");
        
        // Toon een waarschuwing over ontbrekende tabellen
        echo '<div class="alert alert-warning">
                <strong>Let op:</strong> Sommige tabellen ontbreken in de database (' . implode(', ', $missing_tables) . '). 
                Hierdoor worden mogelijk niet alle gegevens getoond.
              </div>';
    }
    $uren = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Haal bedrijfsnaam op (optioneel, als je een aparte tabel wilt kun je dat uitbreiden)
$bedrijfsnaam = isset($_SESSION['bedrijfsnaam']) ? $_SESSION['bedrijfsnaam'] : '';
if ($rol === 'klant' && isset($_POST['bedrijfsnaam'])) {
    $_SESSION['bedrijfsnaam'] = $_POST['bedrijfsnaam'];
    $bedrijfsnaam = $_POST['bedrijfsnaam'];
}

// Haal klantgegevens op (met bedrijfsnaam via JOIN)
if ($rol === 'klant') {
    $stmt_klant = $conn->prepare("SELECT k.*, b.naam AS bedrijfsnaam FROM klant k LEFT JOIN bedrijf b ON k.bedrijf_id = b.id WHERE k.id = :klant_id");
    $stmt_klant->bindParam(':klant_id', $_SESSION['user_id']);
    $stmt_klant->execute();
    $klanten = $stmt_klant->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt_klant = $conn->query("SELECT k.*, b.naam AS bedrijfsnaam FROM klant k LEFT JOIN bedrijf b ON k.bedrijf_id = b.id");
    $klanten = $stmt_klant->fetchAll(PDO::FETCH_ASSOC);
}

// Haal alle klanten op voor de dropdown
$klanten_dropdown = [];
if ($rol !== 'klant') {
    $stmt_klanten = $conn->query("SELECT id, naam FROM klant");
    $klanten_dropdown = $stmt_klanten->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="bg-top"></div>
    <nav class="navbar">
        <img src="Images/logo.png" alt="Logo" class="logo">
        <div class="nav-links">
            <a href="Home.php">Home</a>
            <a href="Contact.php">Contact</a>
            <?php include 'includes/profile_dropdown.php'; ?>
        </div>
    </nav>
    <div class="content">
        <h1>Welcome to Rijen DevOps's Database</h1>
        <div class="main-container">
            <div class="sidebar">
                <?php if ($rol !== 'klant'): ?>
                <button class="sidebar-button active" data-target="medewerker">Medewerker</button>
                <?php endif; ?>
                <button class="sidebar-button" data-target="klant">Klant</button>
                <button class="sidebar-button" data-target="opdracht">Opdracht</button>
                <button class="sidebar-button" data-target="uren">Uren Registratie</button>
                <button class="sidebar-button" data-target="factuur">Factuur</button>
                <?php if ($rol !== 'klant'): ?>
                <button class="sidebar-button" data-target="rol">Rol</button>
                <?php endif; ?>
                <button class="sidebar-button" data-target="order">Order ID</button>
                <?php if ($rol === 'beheerder'): ?>
                    <button class="sidebar-button" onclick="showGebruikersOverzicht()" style="text-align:left;">Gebruikers Overzicht</button>
                    <button class="sidebar-button" onclick="showBedrijfVerzoeken()" style="text-align:left;">Bedrijf Verzoeken</button>
                <?php endif; ?>
            </div>
            <div class="content-area">
                <?php if ($rol !== 'klant'): ?>
                <div id="medewerker" class="database-content active">
                    <h2>Medewerker Database</h2>
                    <p>Beheer alle medewerker gerelateerde informatie in één centrale database.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Naam</th>
                                <th>Functie</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="editable">John Doe</td>
                                <td class="editable">Developer</td>
                                <td class="editable">john@example.com</td>
                                <td class="editable">Actief</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('medewerker')">Voeg medewerker toe</button>
                    </div>
                </div>
                <?php endif; ?>
                <div id="klant" class="database-content">
                    <h2>Klant Database</h2>
                    <?php if ($rol === 'klant'):
                        $bedrijf_id_melding = '';
                        // Verwerk het opslaan van de bedrijfsnaam
                        if (isset($_POST['bedrijfsnaam'])) {
                            $nieuwe_bedrijfsnaam = trim($_POST['bedrijfsnaam']);
                            if ($nieuwe_bedrijfsnaam !== '') {
                                // Kijk of het bedrijf al bestaat
                                $stmt_bedrijf = $conn->prepare("SELECT id FROM bedrijf WHERE naam = :naam LIMIT 1");
                                $stmt_bedrijf->bindParam(':naam', $nieuwe_bedrijfsnaam);
                                $stmt_bedrijf->execute();
                                $bedrijf = $stmt_bedrijf->fetch(PDO::FETCH_ASSOC);
                                if ($bedrijf) {
                                    $bedrijf_id = $bedrijf['id'];
                                } else {
                                    // Voeg nieuw bedrijf toe
                                    $nieuwe_bedrijfscode = strtoupper(uniqid('BC')); // Genereert een unieke bedrijfscode
                                    $stmt_insert = $conn->prepare("INSERT INTO bedrijf (naam, bedrijfscode) VALUES (:naam, :bedrijfscode)");
                                    $stmt_insert->bindParam(':naam', $nieuwe_bedrijfsnaam);
                                    $stmt_insert->bindParam(':bedrijfscode', $nieuwe_bedrijfscode);
                                    $stmt_insert->execute();
                                    $bedrijf_id = $conn->lastInsertId();
                                }
                                // Sla verzoek op voor admin (altijd, ook als bedrijf al bestond)
                                $stmt_verzoek = $conn->prepare("INSERT INTO bedrijf_verzoeken (bedrijf_id, klant_id, status) VALUES (:bedrijf_id, :klant_id, 'nieuw')");
                                $stmt_verzoek->bindParam(':bedrijf_id', $bedrijf_id);
                                $stmt_verzoek->bindParam(':klant_id', $_SESSION['user_id']);
                                $stmt_verzoek->execute();
                                $_SESSION['flash_message'] = 'Uw aanvraag voor bedrijf \'' . htmlspecialchars($nieuwe_bedrijfsnaam) . '\' is ingediend en wordt verwerkt. Het ID van het aangevraagde bedrijf is: <b>' . htmlspecialchars($bedrijf_id) . '</b>';
                                // Update $klanten array zodat de nieuwe bedrijfsnaam/id direct zichtbaar is
                                // Deze query is voor het direct bijwerken van de $klanten variabele na POST, 
                                // de hoofdquery voor weergave staat verderop.
                                $stmt_klant = $conn->prepare("SELECT k.*, b.naam AS bedrijfsnaam, b.status AS bedrijfsstatus FROM klant k LEFT JOIN bedrijf b ON k.bedrijf_id = b.id WHERE k.id = :klant_id");
                                $stmt_klant->bindParam(':klant_id', $_SESSION['user_id']);
                                $stmt_klant->execute();
                                $klanten = $stmt_klant->fetchAll(PDO::FETCH_ASSOC);
                            }
                        }
                        // Logica om status van bedrijfsaanvraag/koppeling te tonen
                        $toonBedrijfsFormulier = true; // Standaard het formulier tonen
                        $klant_info_voor_weergave = null;

                        // Haal de meest actuele klant- en bedrijfsinformatie op voor weergave
                        if (!empty($_SESSION['user_id'])) {
                            $stmt_actuele_klant_info = $conn->prepare(
                                "SELECT k.id AS klant_id_db, k.bedrijf_id, b.naam AS bedrijfsnaam, b.status AS bedrijfsstatus 
                                 FROM klant k 
                                 LEFT JOIN bedrijf b ON k.bedrijf_id = b.id 
                                 WHERE k.id = :klant_id_sessie LIMIT 1"
                            );
                            $stmt_actuele_klant_info->bindParam(':klant_id_sessie', $_SESSION['user_id']);
                            $stmt_actuele_klant_info->execute();
                            $klant_info_voor_weergave = $stmt_actuele_klant_info->fetch(PDO::FETCH_ASSOC);
                        }

                        // Toon flash message als die er is (bijv. na indienen formulier)
                        if (isset($_SESSION['flash_message'])) {
                            echo '<div class="alert alert-info">' . $_SESSION['flash_message'] . '</div>';
                            unset($_SESSION['flash_message']); // Verwijder na tonen
                        }

                        if ($klant_info_voor_weergave && $klant_info_voor_weergave['bedrijf_id']) {
                            if ($klant_info_voor_weergave['bedrijfsstatus'] === 'actief') {
                                echo '<div class="alert alert-success">Uw bedrijf <strong>' . htmlspecialchars($klant_info_voor_weergave['bedrijfsnaam']) . '</strong> (ID: ' . htmlspecialchars($klant_info_voor_weergave['bedrijf_id']) . ') is goedgekeurd en actief!</div>';
                                $toonBedrijfsFormulier = false;
                            } elseif (in_array($klant_info_voor_weergave['bedrijfsstatus'], ['in_afwachting', 'nieuw'])) {
                                echo '<div class="alert alert-info">Uw aanvraag voor bedrijf <strong>' . htmlspecialchars($klant_info_voor_weergave['bedrijfsnaam']) . '</strong> (ID: ' . htmlspecialchars($klant_info_voor_weergave['bedrijf_id']) . ') is in behandeling. Een beheerder zal uw aanvraag beoordelen.</div>';
                                $toonBedrijfsFormulier = false;
                            } else {
                                echo '<div class="alert alert-warning">De status van uw bedrijf (<strong>' . htmlspecialchars($klant_info_voor_weergave['bedrijfsnaam']) . '</strong>, ID: ' . htmlspecialchars($klant_info_voor_weergave['bedrijf_id']) . ') is momenteel: ' . htmlspecialchars($klant_info_voor_weergave['bedrijfsstatus']) . '. Neem contact op met de beheerder als u vragen heeft.</div>';
                                $toonBedrijfsFormulier = false; // Verberg formulier ook bij andere statussen dan 'geen bedrijf'
                            }
                        } elseif (!isset($_SESSION['flash_message'])) { // Voorkom dubbele melding als net ingediend
                             // Geen bedrijf gekoppeld EN geen flash message van net indienen, dus toon standaard prompt
                             echo '<div class="alert alert-secondary">U bent momenteel niet aan een bedrijf gekoppeld. U kunt hieronder een bedrijfsnaam opgeven om een koppeling aan te vragen.</div>';
                        }

                        // Toon het formulier alleen als $toonBedrijfsFormulier waar is
                        if ($toonBedrijfsFormulier):
                    ?>
                    <form method="post" style="margin-bottom: 20px;" class="mt-3">
                        <div class="mb-3">
                            <label for="bedrijfsnaam" class="form-label">Mijn bedrijfsnaam:</label>
                            <input type="text" class="form-control" id="bedrijfsnaam" name="bedrijfsnaam" value="<?php echo ($toonBedrijfsFormulier && isset($klant_info_voor_weergave['bedrijfsnaam'])) ? htmlspecialchars($klant_info_voor_weergave['bedrijfsnaam']) : ''; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Bedrijfsnaam Opgeven / Aanvraag Indienen</button>
                    </form>
                    <?php endif; // Einde van if ($toonBedrijfsFormulier) ?>
                    <?php endif; ?>
                    <p>Centrale opslag van alle klantgegevens en relaties.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Naam</th>
                                <th>E-mail/Telefoon nummer</th>
                                <th>Order ID</th>
                                <th>Bedrijfsnaam</th>
                                <?php if ($rol !== 'klant'): ?><th>Acties</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($klanten as $klant): ?>
                            <tr>
                                <td class="editable"><?php echo htmlspecialchars($klant['naam']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($klant['email'] ?? $klant['telefoon']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($klant['order_id']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($klant['bedrijfsnaam'] ?? ''); ?></td>
                                <?php if ($rol !== 'klant'): ?>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if ($rol !== 'klant'): ?>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('klant')">Voeg klant toe</button>
                    </div>
                    <?php endif; ?>
                </div>
                <div id="opdracht" class="database-content">
                    <h2>Opdracht Database</h2>
                    <p>Beheer van alle lopende en afgeronde opdrachten.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Omschrijving</th>
                                <th>Deadline</th>
                                <th>Klant/Order ID</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="editable">Website ontwikkeling</td>
                                <td class="editable">2024-04-01</td>
                                <td class="editable">ORD-001</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="expand-btn" onclick="showDescription(this)">Details</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table> 
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('opdracht')">Voeg opdracht toe</button>
                    </div>
                </div>
                <div id="uren" class="database-content<?php if ($rol === 'klant') echo ' active'; ?>">
                    <h2>Uren Registratie Database</h2>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Medewerker</th>
                                <th>Project</th>
                                <th>Klant</th>
                                <th>Gewerkte Uren</th>
                                <th>Datum</th>
                                <th>Beschrijving</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($uren as $row): ?>
                            <tr>
                                <td class="editable"><?php echo htmlspecialchars($row['medewerker_id']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($row['project_id']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($row['klant']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($row['uren']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($row['datum']); ?></td>
                                <td class="editable"><?php echo htmlspecialchars($row['beschrijving']); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('uren')" title="Tracking en beheer van gewerkte uren per medewerker en project.">Voeg uren toe</button>
                    </div>
                    <canvas id="urenChart" width="600" height="250"></canvas>
                </div>
                <div id="factuur" class="database-content">
                    <h2>Factuur Database</h2>
                    <p>Beheer van alle facturen en betalingen.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Factuur Nummer</th>
                                <th>Klant</th>
                                <th>Bedrag</th>
                                <th>Status</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="editable">FACT-2024-001</td>
                                <td class="editable">Acme Corp</td>
                                <td class="editable">€1,250.00</td>
                                <td class="editable">Openstaand</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="expand-btn" onclick="showDescription(this)">Details</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('factuur')">Voeg factuur toe</button>
                    </div>
                </div>
                <?php if ($rol !== 'klant'): ?>
                <div id="rol" class="database-content">
                    <h2>Rol Database</h2>
                    <p>Beheer van gebruikersrollen en toegangsrechten.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Rol Naam</th>
                                <th>Beschrijving</th>
                                <th>Toegangsrechten</th>
                                <th>Status</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="editable">Administrator</td>
                                <td class="editable">Volledige toegang tot alle functies</td>
                                <td class="editable">Alle rechten</td>
                                <td class="editable">Actief</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="expand-btn" onclick="showDescription(this)">Details</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('rol')">Voeg rol toe</button>
                    </div>
                </div>
                <?php endif; ?>
                <div id="order" class="database-content">
                    <h2>Order ID Database</h2>
                    <p>Tracking en beheer van alle orders en hun unieke identificaties.</p>
                    <table class="info-grid">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Klant</th>
                                <th>Datum</th>
                                <th>Status</th>
                                <th>Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="editable">ORD-2024-001</td>
                                <td class="editable">Acme Corp</td>
                                <td class="editable">2024-03-20</td>
                                <td class="editable">In behandeling</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-btn" onclick="startRowEdit(this)">Bewerk</button>
                                        <button class="expand-btn" onclick="showDescription(this)">Details</button>
                                        <button class="delete-btn" onclick="deleteRow(this)">Verwijder</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="button-group">
                        <button class="add-row-btn" onclick="showAddModal('order')">Voeg order toe</button>
                    </div>
                </div>
                <div id="gebruikers_overzicht" class="database-content">
                    <!-- Hier wordt het gebruikersoverzicht geladen -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for adding new rows -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Nieuwe Urenregistratie Toevoegen</h3>
            </div>
            <?php if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'klant'): ?>
            <div class="form-group">
                <label for="medewerker_id">Medewerker ID</label>
                <input type="number" id="medewerker_id" min="1" required>
            </div>
            <div class="form-group">
                <label for="klant_id">Klant</label>
                <select id="klant_id" required>
                    <option value="">Selecteer klant</option>
                    <?php foreach ($klanten_dropdown as $klant): ?>
                        <option value="<?php echo $klant['id']; ?>"><?php echo htmlspecialchars($klant['naam']) . ' (ID: ' . $klant['id'] . ')'; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="project_id">Project ID</label>
                <input type="number" id="project_id" min="1" required>
            </div>
            <div class="form-group">
                <label for="uren">Aantal uren *</label>
                <input type="number" id="uren" name="uren" min="0" step="0.01" placeholder="Bijv. 7.5" required>
            </div>
            <div class="form-group">
                <label for="datum">Datum</label>
                <input type="date" id="datum" required>
            </div>
            <div class="form-group">
                <label for="beschrijving">Beschrijving</label>
                <textarea id="beschrijving" class="description-textarea"></textarea>
            </div>
            <div class="modal-buttons">
                <button class="modal-btn cancel-btn" onclick="closeModal()">Annuleren</button>
                <button class="modal-btn save-btn" onclick="saveNewRow()">Opslaan</button>
            </div>
        </div>
    </div>

    <!-- Add the description modal -->
    <div id="descriptionModal" class="description-modal">
        <div class="description-content">
            <div class="description-header">
                <h3>Opdracht Details</h3>
            </div>
            <div class="description-body">
                <div class="description-view">
                    <!-- Description content will be dynamically inserted here -->
                </div>
            </div>
            <div class="modal-buttons">
                <button class="modal-btn cancel-btn" onclick="closeDescriptionModal()">Annuleren</button>
                <button class="modal-btn save-btn" onclick="saveDescription()">Opslaan</button>
            </div>
        </div>
    </div>

    <?php if ($rol === 'klant'): ?>
    <div style="margin: 20px 0;">
        <form method="post">
            <label for="bedrijfsnaam">Mijn bedrijfsnaam:</label>
            <input type="text" id="bedrijfsnaam" name="bedrijfsnaam" value="<?php echo htmlspecialchars($bedrijfsnaam); ?>">
            <button type="submit">Opslaan</button>
        </form>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    <?php if ($rol === 'klant'): ?>
    // Data voor de grafiek
    const urenData = <?php echo json_encode($uren); ?>;
    const labels = [...new Set(urenData.map(u => u.datum))];
    const dataPerDatum = labels.map(d => {
        return urenData.filter(u => u.datum === d).reduce((sum, u) => sum + parseFloat(u.uren), 0);
    });
    const ctx = document.getElementById('urenChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Gewerkte uren',
                data: dataPerDatum,
                backgroundColor: 'rgba(33, 150, 243, 0.7)'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                title: { display: true, text: 'Uren per dag' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
    <?php endif; ?>
        function showAddModal(databaseId) {
            currentDatabaseId = databaseId;
            const modal = document.getElementById('addModal');
        <?php if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'klant'): ?>
        if (document.getElementById('medewerker_id')) document.getElementById('medewerker_id').value = '';
        if (document.getElementById('klant_id')) document.getElementById('klant_id').value = '';
        <?php endif; ?>
        document.getElementById('project_id').value = '';
        document.getElementById('uren').value = '';
        document.getElementById('datum').value = '';
        document.getElementById('beschrijving').value = '';
            modal.style.display = 'block';
        }
        function closeModal() {
            document.getElementById('addModal').style.display = 'none';
    }
    function saveNewRow() {
        console.log('saveNewRow aangeroepen');
        
        // Formulier elementen ophalen
        const medewerkerEl = document.getElementById('medewerker_id');
        const klantEl = document.getElementById('klant_id');
        const projectEl = document.getElementById('project_id');
        const urenEl = document.getElementById('uren');
        const datumEl = document.getElementById('datum');
        const beschrijvingEl = document.getElementById('beschrijving');
        
        // Waarden ophalen en opschonen
        const medewerker_id = medewerkerEl ? medewerkerEl.value.trim() : '';
        const klant_id = klantEl ? klantEl.value.trim() : '';
        const project_id = projectEl ? projectEl.value.trim() : '';
        let uren = urenEl ? urenEl.value.trim() : '';
        const datum = datumEl ? datumEl.value.trim() : '';
        const beschrijving = beschrijvingEl ? beschrijvingEl.value.trim() : '';
        
        console.log('Ingevoerde waarden:', {medewerker_id, klant_id, project_id, uren, datum});
        
        // Validatie
        let errorMessage = [];
        
        // Vereiste velden controleren
        if (medewerkerEl && !medewerker_id) errorMessage.push('Vul een medewerker ID in');
        if (klantEl && !klant_id) errorMessage.push('Selecteer een klant');
        if (!project_id) errorMessage.push('Vul een project ID in');
        
        // Uren validatie
        if (!uren) {
            errorMessage.push('Vul het aantal uren in');
        } else {
            // Vervang komma door punt voor decimale getallen
            uren = uren.replace(',', '.');
            
            // Controleer of het een geldig getal is
            const urenNumber = parseFloat(uren);
            if (isNaN(urenNumber) || urenNumber <= 0) {
                errorMessage.push('Voer een geldig aantal uren in (bijv. 7.5 of 8,5)');
            } else {
                // Formatteer het getal met 2 decimalen
                urenEl.value = urenNumber.toFixed(2);
                uren = urenNumber.toString();
            }
        }
        
        // Datum validatie
        if (!datum) errorMessage.push('Selecteer een datum');
        
        // Toon foutmeldingen als die er zijn
        if (errorMessage.length > 0) {
            alert('Corrigeer de volgende fouten:\n- ' + errorMessage.join('\n- '));
            return;
        }
        
        if (currentDatabaseId === 'uren') {
            console.log('Versturen van urenregistratie...');
            
            // Maak een object met de gegevens
            const formData = new URLSearchParams();
            if (medewerkerEl) formData.append('medewerker_id', medewerker_id);
            if (klantEl) formData.append('klant_id', klant_id);
            formData.append('project_id', project_id);
            formData.append('uren', uren.replace(',', '.')); // Zorg voor juist decimaal teken
            formData.append('datum', datum);
            formData.append('beschrijving', beschrijving);
            
            console.log('Verzonden gegevens:', {
                medewerker_id: medewerkerEl ? medewerker_id : 'n.v.t.',
                klant_id: klantEl ? klant_id : 'n.v.t.',
                project_id,
                uren: uren.replace(',', '.'),
                datum,
                beschrijving
            });
            
            // Toon laadstatus
            const saveBtn = document.querySelector('.save-btn');
            const originalText = saveBtn.textContent;
            saveBtn.disabled = true;
            saveBtn.textContent = 'Bezig met opslaan...';
            
            // Gebruik een absoluut pad voor de API-aanroep
            const url = '/DataBaseDevOps/process_urenregistratie.php';
            console.log('Versturen naar:', url);
            
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin',
                body: formData.toString()
            })
            .then(response => {
                if (!response.ok) {
                    // Probeer de foutdetails als JSON te parsen
                    return response.text().then(text => {
                        try {
                            const data = JSON.parse(text);
                            throw new Error(data.message || 'Er is een fout opgetreden');
                        } catch (e) {
                            throw new Error(`HTTP ${response.status}: ${response.statusText}\n${text}`);
                        }
                    });
                }
                return response.json();
            })
            .catch(error => {
                console.error('Fout bij verwerken verzoek:', error);
                throw error; // Gooi de fout door naar de volgende catch
            })
            .then(data => {
                if (data.success) {
                    // Show success message and close modal
                    alert('Uren succesvol opgeslagen!');
                    // Update de grafiek in plaats van de hele pagina te verversen
                    updateChartWithNewData(data.newEntry);
                    // Sluit het modal
                    document.getElementById('addModal').style.display = 'none';
                } else {
                    alert('Fout bij opslaan: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fout:', error);
                alert('Er is een fout opgetreden bij het opslaan van de uren.');
            })
            .finally(() => {
                // Reset button state
                saveBtn.disabled = false;
                saveBtn.textContent = originalText;
            });
            return;
        }
    }
    
    // Functie om de grafiek bij te werken met nieuwe data
    function updateChartWithNewData(newEntry) {
        // Controleer of de grafiek bestaat
        const chartCanvas = document.getElementById('urenChart');
        if (!chartCanvas) return;
        
        const chart = Chart.getChart(chartCanvas);
        if (!chart) return;
        
        // Voeg de nieuwe data toe aan de grafiek
        const labels = chart.data.labels;
        const data = chart.data.datasets[0].data;
        
        // Zoek of de datum al in de labels zit
        const dateIndex = labels.indexOf(newEntry.datum);
        
        if (dateIndex === -1) {
            // Nieuwe datum toevoegen
            labels.push(newEntry.datum);
            data.push(parseFloat(newEntry.uren));
        } else {
            // Bestaande datum bijwerken
            data[dateIndex] = parseFloat(data[dateIndex] || 0) + parseFloat(newEntry.uren);
        }
        
        // Sorteer de data op datum
        const combined = labels.map((label, i) => ({
            label,
            data: data[i] || 0
        })).sort((a, b) => new Date(a.label) - new Date(b.label));
        
        // Update de grafiek met gesorteerde data
        chart.data.labels = combined.map(item => item.label);
        chart.data.datasets[0].data = combined.map(item => item.data);
        
        // Vernieuw de grafiek
        chart.update();
    }
    document.addEventListener('DOMContentLoaded', function() {
        const buttons = document.querySelectorAll('.sidebar-button');
        const contents = document.querySelectorAll('.database-content');

        buttons.forEach(button => {
            button.addEventListener('click', function() {
                // Verwijder active class van alle knoppen en content
                buttons.forEach(btn => btn.classList.remove('active'));
                contents.forEach(content => content.classList.remove('active'));

                // Voeg active class toe aan de geklikte knop
                this.classList.add('active');

                // Toon de juiste content
                const targetId = this.getAttribute('data-target');
                const targetContent = document.getElementById(targetId);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    });
    function showGebruikersOverzicht() {
        window.location.href = 'gebruikers_overzicht.php';
    }
    function showBedrijfVerzoeken() {
        window.location.href = 'bedrijf_verzoeken.php';
    }
    </script>
</body>
</html>