<?php
require_once 'db_connect.php';

try {
    // Controleer of de gebruikers tabel bestaat
    $stmt = $conn->query("SHOW TABLES LIKE 'gebruikers'");
    if ($stmt->rowCount() == 0) {
        // Maak de gebruikers tabel aan als deze niet bestaat
        $sql = "CREATE TABLE IF NOT EXISTS `gebruikers` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `naam` VARCHAR(100) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `wachtwoord` VARCHAR(255) NOT NULL,
            `rol` ENUM('beheerder', 'klant', 'medewerker') NOT NULL DEFAULT 'klant',
            `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniek_email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $conn->exec($sql);
        echo "Tabel 'gebruikers' aangemaakt.<br>";
    }

    // Verwijder bestaande admin account als deze bestaat
    $stmt = $conn->prepare("DELETE FROM gebruikers WHERE email = 'admin@a.com'");
    $stmt->execute();

    // Voeg nieuw admin account toe
    $naam = 'Beheerder';
    $email = 'admin@a.com';
    $wachtwoord = password_hash('123', PASSWORD_DEFAULT);
    $rol = 'beheerder';
    
    $stmt = $conn->prepare("INSERT INTO `gebruikers` (`naam`, `email`, `wachtwoord`, `rol`) VALUES (:naam, :email, :wachtwoord, :rol)");
    $stmt->bindParam(':naam', $naam);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':wachtwoord', $wachtwoord);
    $stmt->bindParam(':rol', $rol);
    
    if ($stmt->execute()) {
        echo "Beheerder-account succesvol aangemaakt!<br>";
        echo "Email: admin@a.com<br>";
        echo "Wachtwoord: 123<br>";
    } else {
        echo "Fout bij aanmaken beheerder-account.<br>";
    }

    // Verwijder bestaande klant account als deze bestaat
    $stmt = $conn->prepare("DELETE FROM gebruikers WHERE email = 'salar@a.com'");
    $stmt->execute();

    // Voeg nieuw klant account toe
    $naam = 'salar jaffar';
    $email = 'salar@a.com';
    $wachtwoord = password_hash('12', PASSWORD_DEFAULT);
    $rol = 'klant';
    $stmt = $conn->prepare("INSERT INTO `gebruikers` (`naam`, `email`, `wachtwoord`, `rol`) VALUES (:naam, :email, :wachtwoord, :rol)");
    $stmt->bindParam(':naam', $naam);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':wachtwoord', $wachtwoord);
    $stmt->bindParam(':rol', $rol);
    if ($stmt->execute()) {
        echo "Klant-account succesvol aangemaakt!<br>";
        echo "Email: salar@a.com<br>";
        echo "Wachtwoord: 12<br>";
    } else {
        echo "Fout bij aanmaken klant-account.<br>";
    }

} catch(PDOException $e) {
    echo "Database Fout: " . $e->getMessage();
}
?> 