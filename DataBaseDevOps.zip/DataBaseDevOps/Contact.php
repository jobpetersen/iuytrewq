<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .contact-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 500px;
            margin: 50px auto;
        }

        .contact-title {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .input-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            min-height: 150px;
            resize: vertical;
        }

        .submit-button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background: linear-gradient(to right, #4a90e2, #9b59b6);
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: opacity 0.3s;
        }

        .submit-button:hover {
            opacity: 0.9;
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <img src="Images/logo.png" alt="Logo" class="logo">
        <div class="nav-links">
            <a href="Home.php">Home</a>
            <a href="Contact.php">Contact</a>
            <a href="index.php">Log-Out</a>
        </div>
    </div>

    <div class="contact-container">
        <h2 class="contact-title">Contact Us</h2>
        <?php
        if (isset($_GET['status'])) {
            if ($_GET['status'] === 'success') {
                echo '<div class="message success">Your message has been sent successfully!</div>';
            } else if ($_GET['status'] === 'error') {
                echo '<div class="message error">Sorry, there was an error sending your message. Please try again.</div>';
            }
        }
        ?>
        <form action="process_contact.php" method="POST">
            <div class="input-group">
                <input type="text" name="name" placeholder="Your Name" required>
            </div>
            <div class="input-group">
                <input type="email" name="email" placeholder="Your Email" required>
            </div>
            <div class="input-group">
                <textarea name="message" placeholder="Your Message" required></textarea>
            </div>
            <button type="submit" class="submit-button">Send Message</button>
        </form>
    </div>
</body>
</html>
