<?php
/**
 * Script om de bedrijf_verzoeken tabel bij te werken met de 'nieuw' status
 */

require_once 'db_connect.php';

try {
    // Controleer of de tabel bestaat
    $checkTable = $conn->query("SHOW TABLES LIKE 'bedrijf_verzoeken'");
    if ($checkTable->rowCount() === 0) {
        die("De tabel 'bedrijf_verzoeken' bestaat niet in de database.");
    }
    
    // Controleer of de status kolom al het juiste ENUM type heeft
    $checkColumn = $conn->query("SHOW COLUMNS FROM bedrijf_verzoeken WHERE Field = 'status'");
    $columnInfo = $checkColumn->fetch(PDO::FETCH_ASSOC);
    
    if (strpos($columnInfo['Type'], "'nieuw'") === false) {
        // Voeg de 'nieuw' status toe aan de ENUM
        $alterSql = "ALTER TABLE bedrijf_verzoeken 
                   MODIFY COLUMN status 
                   ENUM('nieuw', 'in_afwachting', 'goedgekeurd', 'afgewezen') 
                   NOT NULL DEFAULT 'nieuw'";
        
        $conn->exec($alterSql);
        echo "De tabel 'bedrijf_verzoeken' is succesvol bijgewerkt met de 'nieuw' status.\n";
    } else {
        echo "De tabel 'bedrijf_verzoeken' heeft al de juiste instellingen.\n";
    }
    
    // Toon de huidige instellingen van de status kolom
    $result = $conn->query("SHOW COLUMNS FROM bedrijf_verzoeken WHERE Field = 'status'");
    $row = $result->fetch(PDO::FETCH_ASSOC);
    echo "Huidige instellingen van de status kolom: " . $row['Type'] . "\n";
    
} catch (PDOException $e) {
    echo "Er is een fout opgetreden: " . $e->getMessage() . "\n";
    echo "Bestand: " . $e->getFile() . " (Regel: " . $e->getLine() . ")\n";
}

echo "Klaar.\n";
