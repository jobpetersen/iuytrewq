<?php if (isset($_SESSION['user_id'])): ?>
<div class="profile-dropdown">
    <button class="profile-btn">
        <i class="fas fa-user-circle"></i>
        <span><?php echo htmlspecialchars(explode('@', $_SESSION['email'])[0]); ?></span>
    </button>
    <div class="dropdown-content">
        <div class="user-email"><?php echo htmlspecialchars($_SESSION['email']); ?></div>
        <a href="profile.php"><i class="fas fa-user"></i> Mijn Profiel</a>
        <a href="settings.php"><i class="fas fa-cog"></i> Instellingen</a>
        <div class="dropdown-divider"></div>
        <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Uitloggen</a>
    </div>
</div>
<?php else: ?>
    <a href="login.php" class="login-btn">Inloggen</a>
<?php endif; ?>
