<?php
// id_overzicht.php
// Overzicht van alle gebruikers en klanten

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'db_connect.php';

// Haal alle gebruikers op
$stmt = $conn->query("SELECT id, naam, email, rol FROM gebruikers ORDER BY id");
$gebruikers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Haal alle klanten op
$stmt = $conn->query("SELECT id, naam, email, telefoon, order_id FROM klant ORDER BY id");
$klanten = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Overzicht</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { padding: 20px; }
        h1 { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 40px; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <h1>ID Overzicht</h1>
        <h2>Gebruikers</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Naam</th>
                    <th>Email</th>
                    <th>Rol</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($gebruikers as $gebruiker): ?>
                <tr>
                    <td><?php echo htmlspecialchars($gebruiker['id']); ?></td>
                    <td><?php echo htmlspecialchars($gebruiker['naam']); ?></td>
                    <td><?php echo htmlspecialchars($gebruiker['email']); ?></td>
                    <td><?php echo htmlspecialchars($gebruiker['rol']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <h2>Klanten</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Naam</th>
                    <th>Email</th>
                    <th>Telefoon</th>
                    <th>Order ID</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($klanten as $klant): ?>
                <tr>
                    <td><?php echo htmlspecialchars($klant['id']); ?></td>
                    <td><?php echo htmlspecialchars($klant['naam']); ?></td>
                    <td><?php echo htmlspecialchars($klant['email']); ?></td>
                    <td><?php echo htmlspecialchars($klant['telefoon']); ?></td>
                    <td><?php echo htmlspecialchars($klant['order_id']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="Home.php" class="btn btn-primary">Terug naar Home</a>
    </div>
</body>
</html> 