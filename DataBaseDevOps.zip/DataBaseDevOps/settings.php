<?php
session_start();

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Databaseverbinding
require_once 'db_connect.php';

$success = '';
$error = '';

// Gebruikersgegevens ophalen
$stmt = $conn->prepare("SELECT * FROM gebruikers WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['error'] = "Gebruiker niet gevonden.";
    header('Location: Home.php');
    exit();
}

// Formulier verwerken
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = trim($_POST['naam'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefoon = trim($_POST['telefoon'] ?? '');
    $huidig_wachtwoord = $_POST['huidig_wachtwoord'] ?? '';
    $nieuw_wachtwoord = $_POST['nieuw_wachtwoord'] ?? '';
    $bevestig_wachtwoord = $_POST['bevestig_wachtwoord'] ?? '';

    try {
        $conn->beginTransaction();
        
        // Alleen bijwerken wat is ingevuld
        $updateFields = [];
        $updateData = ['id' => $_SESSION['user_id']];
        
        // Alleen naam bijwerken als deze is ingevuld
        if (!empty($naam)) {
            $updateFields[] = 'naam = :naam';
            $updateData['naam'] = $naam;
        }
        
        // Alleen e-mail bijwerken als deze is ingevuld en geldig is
        if (!empty($email)) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Voer een geldig e-mailadres in.");
            }
            $updateFields[] = 'email = :email';
            $updateData['email'] = $email;
        }
        
        // Alleen telefoon bijwerken als deze is ingevuld
        if (!empty($telefoon)) {
            $updateFields[] = 'telefoon = :telefoon';
            $updateData['telefoon'] = $telefoon;
        }
        
        // Wachtwoord bijwerken indien ingevuld
        if (!empty($huidig_wachtwoord) || !empty($nieuw_wachtwoord) || !empty($bevestig_wachtwoord)) {
            // Alleen controleren als er iets is ingevuld in een van de wachtwoordvelden
            if (empty($huidig_wachtwoord) || empty($nieuw_wachtwoord) || empty($bevestig_wachtwoord)) {
                throw new Exception("Vul alle wachtwoordvelden in om uw wachtwoord te wijzigen.");
            }
            
            if (!password_verify($huidig_wachtwoord, $user['wachtwoord'])) {
                throw new Exception("Huidig wachtwoord is onjuist.");
            }
            
            if ($nieuw_wachtwoord !== $bevestig_wachtwoord) {
                throw new Exception("Nieuwe wachtwoorden komen niet overeen.");
            }
            
            if (strlen($nieuw_wachtwoord) < 8) {
                throw new Exception("Wachtwoord moet minimaal 8 tekens lang zijn.");
            }
            
            $updateFields[] = 'wachtwoord = :wachtwoord';
            $updateData['wachtwoord'] = password_hash($nieuw_wachtwoord, PASSWORD_DEFAULT);
        }
        
        // Alleen bijwerken als er iets is om bij te werken
        if (!empty($updateFields)) {
            $sql = "UPDATE gebruikers SET " . implode(', ', $updateFields) . " WHERE id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute($updateData);
            
            $conn->commit();
            $success = "Instellingen succesvol opgeslagen!";
            
            // Vernieuw gebruikersgegevens
            $stmt = $conn->prepare("SELECT * FROM gebruikers WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $success = "Geen wijzigingen om op te slaan.";
        }
        
    } catch (Exception $e) {
        $conn->rollBack();
        $error = $e->getMessage();
    }
}

$pageTitle = "Instellingen";
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Rijen DevOps</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .settings-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .settings-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #444;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: #2196F3;
            outline: none;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #0d8aee;
        }
        
        .btn-danger {
            background: #f44336;
        }
        
        .btn-danger:hover {
            background: #e53935;
        }
        
        .section-title {
            font-size: 18px;
            margin: 30px 0 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
            color: #2196F3;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
        
        .alert-danger {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>
    <div class="bg-top"></div>
    <nav class="navbar">
        <a href="Home.php">
            <img src="Images/logo.png" alt="Logo" class="logo">
        </a>
        <div class="nav-links">
            <a href="Home.php">Home</a>
            <a href="Contact.php">Contact</a>
            <?php include 'includes/profile_dropdown.php'; ?>
        </div>
    </nav>

    <div class="content">
        <div class="settings-container">
            <h1><i class="fas fa-cog"></i> Instellingen</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <div class="settings-card">
                <form method="POST" action="settings.php">
                    <h3 class="section-title">
                        <i class="fas fa-user"></i> Profielgegevens
                    </h3>
                    
                    <div class="form-group">
                        <label for="naam">Volledige naam</label>
                        <input type="text" id="naam" name="naam" class="form-control" 
                               value="<?php echo htmlspecialchars($user['naam']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mailadres</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="telefoon">Telefoonnummer</label>
                        <input type="tel" id="telefoon" name="telefoon" class="form-control" 
                               value="<?php echo htmlspecialchars($user['telefoon'] ?? ''); ?>">
                    </div>
                    
                    <h3 class="section-title">
                        <i class="fas fa-lock"></i> Wachtwoord wijzigen
                        <small class="text-muted">(Laat leeg om niet te wijzigen)</small>
                    </h3>
                    
                    <div class="form-group">
                        <label for="huidig_wachtwoord">Huidig wachtwoord</label>
                        <input type="password" id="huidig_wachtwoord" name="huidig_wachtwoord" 
                               class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="nieuw_wachtwoord">Nieuw wachtwoord</label>
                        <input type="password" id="nieuw_wachtwoord" name="nieuw_wachtwoord" 
                               class="form-control" minlength="8">
                        <small class="text-muted">Minimaal 8 tekens</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="bevestig_wachtwoord">Bevestig nieuw wachtwoord</label>
                        <input type="password" id="bevestig_wachtwoord" name="bevestig_wachtwoord" 
                               class="form-control">
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn">
                            <i class="fas fa-save"></i> Opslaan
                        </button>
                        <a href="profile.php" class="btn" style="background: #6c757d; margin-left: 10px;">
                            <i class="fas fa-arrow-left"></i> Terug naar profiel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>
