<?php
/**
 * Database setup script
 * 
 * Dit script maakt de database en tabellen aan als ze nog niet bestaan.
 */

// Laad de database configuratie
require_once 'db_connect.php';

// Functie om een SQL bestand uit te voeren
function executeSqlFile($pdo, $file) {
    if (!file_exists($file)) {
        die("Fout: Bestand niet gevonden: $file");
    }
    
    $sql = file_get_contents($file);
    
    try {
        $pdo->exec($sql);
        echo "<p style='color: green;'>Bestand succesvol uitgevoerd: " . basename($file) . "</p>";
        return true;
    } catch (PDOException $e) {
        echo "<p style='color: red;'>Fout bij uitvoeren van " . basename($file) . ": " . $e->getMessage() . "</p>";
        return false;
    }
}

// Maak verbinding zonder database te specificeren
try {
    $config = [
        'host' => 'localhost',
        'username' => 'root',
        'password' => '',
        'dbname' => 'database_devops',
        'charset' => 'utf8mb4',
        'port' => 3306
    ];
    
    $dsn = "mysql:host={$config['host']};charset={$config['charset']}";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, $config['username'], $config['password'], $options);
    
    // Maak de database aan als deze nog niet bestaat
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    
    // Selecteer de database
    $pdo->exec("USE `{$config['dbname']}`");
    
    echo "<h2>Database setup</h2>";
    echo "<p>Database '{$config['dbname']}' is geselecteerd of aangemaakt.</p>";
    
    // Maak de tabellen aan
    echo "<h3>Tabellen aanmaken:</h3>";
    
    // SQL commando's voor het aanmaken van de tabellen
    $sql_commands = [
        // Eerst de gebruikers tabel (zodat we er naar kunnen verwijzen)
        "gebruikers" => "CREATE TABLE IF NOT EXISTS `gebruikers` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `naam` VARCHAR(100) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `wachtwoord` VARCHAR(255) NOT NULL,
            `rol` ENUM('beheerder', 'klant', 'medewerker', 'bedrijf') NOT NULL DEFAULT 'klant',
            `telefoon` VARCHAR(20) DEFAULT NULL,
            `actief` TINYINT(1) NOT NULL DEFAULT 1,
            `laatst_ingelogd` DATETIME DEFAULT NULL,
            `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `gewijzigd_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniek_email` (`email`),
            KEY `idx_rol` (`rol`),
            KEY `idx_actief` (`actief`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        // Dan de bedrijven tabel
        "bedrijf" => "CREATE TABLE IF NOT EXISTS `bedrijf` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `naam` VARCHAR(100) NOT NULL,
            `kvk_nummer` VARCHAR(20) DEFAULT NULL,
            `btw_nummer` VARCHAR(20) DEFAULT NULL,
            `straat` VARCHAR(100) DEFAULT NULL,
            `huisnummer` VARCHAR(10) DEFAULT NULL,
            `postcode` VARCHAR(10) DEFAULT NULL,
            `plaats` VARCHAR(100) DEFAULT NULL,
            `land` VARCHAR(50) DEFAULT 'Nederland',
            `telefoon` VARCHAR(20) DEFAULT NULL,
            `email` VARCHAR(100) NOT NULL,
            `website` VARCHAR(255) DEFAULT NULL,
            `actief` TINYINT(1) NOT NULL DEFAULT 1,
            `aangemaakt_door` INT DEFAULT NULL,
            `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `gewijzigd_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniek_kvk` (`kvk_nummer`),
            UNIQUE KEY `uniek_btw` (`btw_nummer`),
            KEY `idx_naam` (`naam`),
            KEY `idx_actief` (`actief`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        // Dan de bedrijf_verzoeken tabel (na bedrijf en gebruikers)
        "bedrijf_verzoeken" => "CREATE TABLE IF NOT EXISTS `bedrijf_verzoeken` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `bedrijf_id` INT NOT NULL,
            `klant_id` INT NOT NULL,
            `status` ENUM('in_afwachting', 'goedgekeurd', 'afgewezen') NOT NULL DEFAULT 'in_afwachting',
            `opmerking` TEXT DEFAULT NULL,
            `verwerkt_door` INT DEFAULT NULL,
            `verwerkt_op` DATETIME DEFAULT NULL,
            `aangemaakt_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `gewijzigd_op` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_bedrijf` (`bedrijf_id`),
            KEY `idx_klant` (`klant_id`),
            KEY `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        
        // Dan de sessies tabel
        "sessies" => "CREATE TABLE IF NOT EXISTS `sessies` (
            `id` VARCHAR(128) NOT NULL,
            `gebruiker_id` INT DEFAULT NULL,
            `ip_adres` VARCHAR(45) NOT NULL,
            `user_agent` TEXT,
            `laatste_activiteit` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            `data` TEXT,
            PRIMARY KEY (`id`),
            KEY `idx_gebruiker` (`gebruiker_id`),
            KEY `idx_laatste_activiteit` (`laatste_activiteit`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    ];
    
    // Voer de SQL commando's uit
    foreach ($sql_commands as $table => $sql) {
        try {
            $pdo->exec($sql);
            echo "<p style='color: green;'>Tabel '$table' is aangemaakt of bestond al.</p>";
        } catch (PDOException $e) {
            echo "<p style='color: red;'>Fout bij aanmaken tabel '$table': " . $e->getMessage() . "</p>";
        }
    }
    
    // Nu voegen we de foreign keys toe (dit doen we apart om eventuele volgordeproblemen te voorkomen)
    $foreign_keys = [
        "ALTER TABLE `bedrijf` 
         ADD CONSTRAINT `fk_bedrijf_aangemaakt_door` 
         FOREIGN KEY (`aangemaakt_door`) 
         REFERENCES `gebruikers` (`id`) ON DELETE SET NULL",
         
        "ALTER TABLE `bedrijf_verzoeken` 
         ADD CONSTRAINT `fk_verzoek_bedrijf` 
         FOREIGN KEY (`bedrijf_id`) 
         REFERENCES `bedrijf` (`id`) ON DELETE CASCADE",
         
        "ALTER TABLE `bedrijf_verzoeken` 
         ADD CONSTRAINT `fk_verzoek_klant` 
         FOREIGN KEY (`klant_id`) 
         REFERENCES `gebruikers` (`id`) ON DELETE CASCADE",
         
        "ALTER TABLE `bedrijf_verzoeken` 
         ADD CONSTRAINT `fk_verwerkt_door` 
         FOREIGN KEY (`verwerkt_door`) 
         REFERENCES `gebruikers` (`id`) ON DELETE SET NULL",
         
        "ALTER TABLE `sessies` 
         ADD CONSTRAINT `fk_sessie_gebruiker` 
         FOREIGN KEY (`gebruiker_id`) 
         REFERENCES `gebruikers` (`id`) ON DELETE CASCADE"
    ];
    
    echo "<h3>Foreign keys toevoegen:</h3>";
    
    foreach ($foreign_keys as $sql) {
        try {
            $pdo->exec($sql);
            echo "<p style='color: green;'>Foreign key succesvol toegevoegd.</p>";
        } catch (PDOException $e) {
            echo "<p style='color: orange;'>Opmerking bij toevoegen foreign key: " . $e->getMessage() . "</p>";
        }
    }
    
    // Controleer of er een admin gebruiker bestaat
    $stmt = $pdo->query("SELECT id FROM gebruikers WHERE email = 'admin@example.com'");
    if ($stmt->rowCount() === 0) {
        // Voeg een standaard admin gebruiker toe
        $wachtwoord = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO `gebruikers` (`naam`, `email`, `wachtwoord`, `rol`) 
                    VALUES ('Beheerder', 'admin@example.com', '$wachtwoord', 'beheerder')");
        
        echo "<div style='background-color: #dff0d8; border: 1px solid #d6e9c6; color: #3c763d; padding: 15px; margin: 15px 0; border-radius: 4px;'>";
        echo "<h3>Standaard admin gebruiker aangemaakt</h3>";
        echo "<p>Er is een standaard admin gebruiker aangemaakt met de volgende gegevens:</p>";
        echo "<ul>";
        echo "<li><strong>E-mail:</strong> admin@example.com</li>";
        echo "<li><strong>Wachtwoord:</strong> admin123</li>";
        echo "<li><strong>Let op:</strong> Verander direct na het inloggen het wachtwoord!</li>";
        echo "</ul>";
        echo "</div>";
    }
    
    echo "<div style='background-color: #d9edf7; border: 1px solid #bce8f1; color: #31708f; padding: 15px; margin: 15px 0; border-radius: 4px;'>";
    echo "<h3>Database setup voltooid</h3>";
    echo "<p>De database en tabellen zijn succesvol aangemaakt. Je kunt nu <a href='index.php'>terug naar de hoofdpagina</a>.</p>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='background-color: #f2dede; border: 1px solid #ebccd1; color: #a94442; padding: 15px; margin: 15px 0; border-radius: 4px;'>";
    echo "<h3>Er is een fout opgetreden:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Bestand: " . htmlspecialchars($e->getFile()) . " (Regel: " . $e->getLine() . ")</p>";
    
    // Toon specifieke oplossingen voor veelvoorkomende problemen
    if (strpos($e->getMessage(), 'Access denied') !== false) {
        echo "<h4>Oplossing:</h4>";
        echo "<p>Controleer of de gebruikersnaam en het wachtwoord in db_connect.php kloppen.</p>";
    } elseif (strpos($e->getMessage(), 'Connection refused') !== false) {
        echo "<h4>Oplossing:</h4>";
        echo "<p>Kan geen verbinding maken met de MySQL server. Controleer of de MySQL service actief is.</p>";
    }
    
    echo "</div>
    <pre>";
    print_r($e);
    echo "</pre>";
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 20px;
        color: #333;
    }
    h1, h2, h3 {
        color: #2c3e50;
    }
    .success {
        color: #3c763d;
        background-color: #dff0d8;
        border: 1px solid #d6e9c6;
        padding: 15px;
        margin: 15px 0;
        border-radius: 4px;
    }
    .error {
        color: #a94442;
        background-color: #f2dede;
        border: 1px solid #ebccd1;
        padding: 15px;
        margin: 15px 0;
        border-radius: 4px;
    }
    .warning {
        color: #8a6d3b;
        background-color: #fcf8e3;
        border: 1px solid #faebcc;
        padding: 15px;
        margin: 15px 0;
        border-radius: 4px;
    }
    pre {
        background: #f5f5f5;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        overflow-x: auto;
    }
</style>
