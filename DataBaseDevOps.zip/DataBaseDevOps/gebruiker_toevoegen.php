<?php
// gebruiker_toevoegen.php
// Script om nieuwe gebruikers toe te voegen of te bewerken

// Start de sessie
session_start();

// Controleer of de gebruiker is ingelogd en een beheerder is
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'beheerder') {
    header('Location: Home.php');
    exit;
}

require_once 'db_connect.php';

$error = '';
$success = '';
$rollen = ['beheerder', 'medewerker', 'klant'];
$isEdit = isset($_GET['edit']) && is_numeric($_GET['edit']);
$gebruiker = null;

// Haal gebruikersgegevens op als we aan het bewerken zijn
if ($isEdit) {
    $stmt = $conn->prepare("SELECT id, naam, email, rol FROM gebruikers WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $gebruiker = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$gebruiker) {
        header('Location: gebruikers_overzicht.php?error=Gebruiker niet gevonden');
        exit;
    }
}

// Verwerk het formulier bij verzending
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Valideer invoer
        $naam = trim($_POST['naam'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $wachtwoord = $_POST['wachtwoord'] ?? '';
        $bevestig_wachtwoord = $_POST['bevestig_wachtwoord'] ?? '';
        $rol = $_POST['rol'] ?? '';
        $id = $_POST['id'] ?? null;
        $isEdit = !empty($id);
        
        // Controleer verplichte velden
        if (empty($naam) || empty($email) || empty($rol)) {
            throw new Exception('Vul alle verplichte velden in');
        }
        
        // Valideer e-mail
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Ongeldig e-mailadres');
        }
        
        // Controleer of e-mail al bestaat (behalve voor de huidige gebruiker bij bewerken)
        $stmt = $conn->prepare("SELECT id FROM gebruikers WHERE email = ? AND id != ?");
        $stmt->execute([$email, $id]);
        if ($stmt->fetch()) {
            throw new Exception('Dit e-mailadres is al in gebruik');
        }
        
        // Wachtwoord validatie alleen bij toevoegen of bij wijzigen
        if (!$isEdit || !empty($wachtwoord)) {
            if ($wachtwoord !== $bevestig_wachtwoord) {
                throw new Exception('Wachtwoorden komen niet overeen');
            }
            if (strlen($wachtwoord) < 8) {
                throw new Exception('Wachtwoord moet minimaal 8 tekens lang zijn');
            }
        }
        
        if ($isEdit) {
            // Bestaande gebruiker bijwerken
            if (!empty($wachtwoord)) {
                // Wachtwoord bijwerken
                $wachtwoord_hash = password_hash($wachtwoord, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE gebruikers SET naam = ?, email = ?, wachtwoord = ?, rol = ? WHERE id = ?");
                $result = $stmt->execute([$naam, $email, $wachtwoord_hash, $rol, $id]);
            } else {
                // Alleen gegevens bijwerken, wachtwoord blijft hetzelfde
                $stmt = $conn->prepare("UPDATE gebruikers SET naam = ?, email = ?, rol = ? WHERE id = ?");
                $result = $stmt->execute([$naam, $email, $rol, $id]);
            }
            
            if ($result) {
                $success = 'Gebruiker succesvol bijgewerkt';
            } else {
                throw new Exception('Er is een fout opgetreden bij het bijwerken van de gebruiker');
            }
        } else {
            // Nieuwe gebruiker toevoegen
            if (empty($wachtwoord)) {
                throw new Exception('Vul een wachtwoord in');
            }
            
            $wachtwoord_hash = password_hash($wachtwoord, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO gebruikers (naam, email, wachtwoord, rol) VALUES (?, ?, ?, ?)");
            
            if ($stmt->execute([$naam, $email, $wachtwoord_hash, $rol])) {
                $success = 'Gebruiker succesvol toegevoegd';
                // Wis de velden na succesvol toevoegen
                $_POST = [];
                $gebruiker = null;
            } else {
                throw new Exception('Er is een fout opgetreden bij het toevoegen van de gebruiker');
            }
        }
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gebruiker Toevoegen</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { padding: 20px; }
        .form-container { max-width: 600px; margin: 0 auto; }
        .error { color: #dc3545; margin-bottom: 15px; }
        .success { color: #28a745; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1 class="mb-4"><?php echo $isEdit ? 'Gebruiker Bewerken' : 'Nieuwe Gebruiker Toevoegen'; ?></h1>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="naam">Naam *</label>
                    <input type="text" class="form-control" id="naam" name="naam" 
                           value="<?php echo htmlspecialchars($_POST['naam'] ?? ($gebruiker['naam'] ?? '')); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">E-mailadres *</label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ($gebruiker['email'] ?? '')); ?>" required>
                </div>
                
                <?php if ($isEdit): ?>
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($gebruiker['id']); ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="wachtwoord"><?php echo $isEdit ? 'Nieuw ' : ''; ?>Wachtwoord <?php echo $isEdit ? '' : '*'; ?></label>
                    <input type="password" class="form-control" id="wachtwoord" name="wachtwoord" 
                           <?php echo $isEdit ? '' : 'required'; ?> 
                           placeholder="<?php echo $isEdit ? 'Laat leeg om het huidige wachtwoord te behouden' : ''; ?>">
                    <?php if ($isEdit): ?>
                        <small class="form-text text-muted">Vul alleen in als je het wachtwoord wilt wijzigen</small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group" id="bevestigWachtwoordGroup" style="display: <?php echo $isEdit ? 'none' : 'block'; ?>">
                    <label for="bevestig_wachtwoord">Bevestig <?php echo $isEdit ? 'Nieuw ' : ''; ?>Wachtwoord <?php echo $isEdit ? '' : '*'; ?></label>
                    <input type="password" class="form-control" id="bevestig_wachtwoord" name="bevestig_wachtwoord" 
                           <?php echo $isEdit ? '' : 'required'; ?>>
                </div>
                
                <div class="form-group">
                    <label for="rol">Rol *</label>
                    <select class="form-control" id="rol" name="rol" required>
                        <option value="">Selecteer een rol</option>
                        <?php foreach ($rollen as $rol): ?>
                            <option value="<?php echo htmlspecialchars($rol); ?>"
                                <?php echo (isset($_POST['rol']) && $_POST['rol'] === $rol) || ($gebruiker && $gebruiker['rol'] === $rol) ? 'selected' : ''; ?>>
                                <?php echo ucfirst(htmlspecialchars($rol)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo $isEdit ? 'Opslaan' : 'Toevoegen'; ?>
                    </button>
                    <a href="gebruikers_overzicht.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Annuleren
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toon/verberg bevestig wachtwoord veld op basis van wachtwoord veld
            $('#wachtwoord').on('input', function() {
                if ($(this).val().length > 0) {
                    $('#bevestigWachtwoordGroup').show();
                    $('#bevestig_wachtwoord').prop('required', true);
                } else {
                    $('#bevestigWachtwoordGroup').hide();
                    $('#bevestig_wachtwoord').prop('required', false).val('');
                }
            });
            
            // Valideer formulier
            $('form').on('submit', function(e) {
                const wachtwoord = $('#wachtwoord').val();
                const bevestigWachtwoord = $('#bevestig_wachtwoord').val();
                
                if (wachtwoord !== '' && wachtwoord !== bevestigWachtwoord) {
                    e.preventDefault();
                    alert('Wachtwoorden komen niet overeen');
                    return false;
                }
                
                return true;
            });
        });
    </script>
</body>
</html>
