<?php
session_start();

// Functie om veilig om te leiden met een bericht
function redirectWithMessage($url, $type, $message) {
    $_SESSION[$type . '_message'] = $message; // Zorgt voor 'success_message' of 'error_message'
    header("Location: $url");
    exit();
}

// Controleer of de gebruiker is ingelogd en een beheerder is
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'beheerder') {
    redirectWithMessage('index.php', 'error', 'U moet ingelogd zijn als beheerder om deze actie uit te voeren');
}

// Controleer of dit een bevestiging is
$bevestigd = isset($_POST['bevestigd']) && $_POST['bevestigd'] === 'ja';

// Script verwacht POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithMessage('bedrijf_verzoeken.php', 'error', 'Ongeldige request methode. POST verwacht.');
}

// Haal verzoek ID op uit POST data
if (!isset($_POST['verzoek_id']) || !is_numeric($_POST['verzoek_id'])) {
    redirectWithMessage('bedrijf_verzoeken.php', 'error', 'Verzoek ID ontbreekt of is ongeldig.');
}
$verzoekId = (int)$_POST['verzoek_id'];

// Haal actie op uit POST data
if (!isset($_POST['actie']) || !in_array($_POST['actie'], ['goedkeuren', 'afwijzen'])) {
    redirectWithMessage('bedrijf_verzoeken.php', 'error', 'Actie ontbreekt of is ongeldig.');
}
$actie = $_POST['actie'];
$actieTekst = $actie === 'goedkeuren' ? 'goedkeuren' : 'afwijzen';

// Database verbinding
require_once 'db_connect.php';

// Functie om de basis HTML-structuur te genereren
function generateHtmlHeader($title) {
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($title); ?> - DataBaseDevOps</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                background-color: #f8f9fa;
                padding-top: 20px;
            }
            .card {
                border: none;
                box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
                margin-bottom: 2rem;
            }
            .card-header {
                font-weight: 600;
            }
            .btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 0.5rem;
            }
            .btn i {
                font-size: 1rem;
            }
            .spinner-border {
                width: 1.5rem;
                height: 1.5rem;
            }
            dl.row dt {
                font-weight: 500;
                color: #6c757d;
            }
            .alert h5 {
                font-weight: 600;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8">
                    <div class="text-center mb-4">
                        <h1 class="h3 mb-0">DataBaseDevOps</h1>
                        <p class="text-muted">Beheerpaneel</p>
                    </div>
    <?php
}

// Functie om de footer te genereren
function generateHtmlFooter() {
    ?>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Voorkom dubbel indienen van formulieren
            document.addEventListener('DOMContentLoaded', function() {
                const form = document.querySelector('form');
                if (form) {
                    form.addEventListener('submit', function(e) {
                        const submitButton = form.querySelector('button[type="submit"]');
                        if (submitButton && !form.dataset.submitted) {
                            form.dataset.submitted = 'true';
                            submitButton.disabled = true;
                            const originalHtml = submitButton.innerHTML;
                            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Bezig met verwerken...';
                            
                            // Herstel de knop als het formulier niet wordt doorgestuurd
                            setTimeout(() => {
                                if (form.dataset.submitted === 'true') {
                                    submitButton.disabled = false;
                                    submitButton.innerHTML = originalHtml;
                                    form.dataset.submitted = 'false';
                                }
                            }, 10000);
                        }
                    });
                }
            });
        </script>
    </body>
    </html>
    <?php
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $bevestigd) {
        // Bevestigingsstap - voer de actie uit
        $conn->beginTransaction();
        
        // Haal het verzoek op met een lock om race conditions te voorkomen
        $stmt = $conn->prepare("SELECT * FROM bedrijf_verzoeken WHERE id = ? LIMIT 1 FOR UPDATE");
        $stmt->execute([$verzoekId]);
        $verzoek = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$verzoek) {
            throw new Exception('Verzoek niet gevonden');
        }
        
        // Controleer of het verzoek al verwerkt is
        if (!in_array($verzoek['status'], ['nieuw', 'in_afwachting'])) {
            throw new Exception('Dit verzoek is al verwerkt');
        }
        
        // Update de status van het verzoek
        $nieuweStatus = $actie === 'goedkeuren' ? 'goedgekeurd' : 'afgewezen';
        $stmt = $conn->prepare("UPDATE bedrijf_verzoeken SET status = ?, verwerkt_op = NOW() WHERE id = ?");
        $stmt->execute([$nieuweStatus, $verzoekId]);
        
        // Als het verzoek is goedgekeurd, activeer het bedrijf
        if ($actie === 'goedkeuren' && !empty($verzoek['bedrijf_id'])) {
            $stmt = $conn->prepare("UPDATE bedrijf SET status = 'actief' WHERE id = ?");
            $stmt->execute([$verzoek['bedrijf_id']]);
            
            // Voeg de gebruiker toe aan het bedrijf als eigenaar
            if (!empty($verzoek['klant_id'])) {
                $stmt = $conn->prepare("INSERT INTO bedrijf_gebruikers (bedrijf_id, gebruiker_id, rol, toegevoegd_op) 
                                      VALUES (?, ?, 'eigenaar', NOW())
                                      ON DUPLICATE KEY UPDATE rol = 'eigenaar', bijgewerkt_op = NOW()");
                $stmt->execute([$verzoek['bedrijf_id'], $verzoek['klant_id']]);
            }

            // Koppel klant aan bedrijf in de 'klant' tabel
            if (!empty($verzoek['klant_id']) && !empty($verzoek['bedrijf_id'])) {
                $stmt_koppel_klant = $conn->prepare("UPDATE klant SET bedrijf_id = ? WHERE id = ?");
                $stmt_koppel_klant->execute([$verzoek['bedrijf_id'], $verzoek['klant_id']]);
            }
        }
        
        $conn->commit();
        
        // Toon bevestigingspagina
        $paginaTitel = 'Verzoek ' . ($actie === 'goedkeuren' ? 'goedgekeurd' : 'afgewezen');
        $bericht = 'Het verzoek is succesvol ' . ($actie === 'goedkeuren' ? 'goedgekeurd' : 'afgewezen') . '.';
        
        generateHtmlHeader($paginaTitel);
        ?>
        <div class="card shadow-sm">
            <div class="card-header bg-<?php echo $actie === 'goedkeuren' ? 'success' : 'danger'; ?> text-white">
                <h4 class="mb-0"><?php echo htmlspecialchars($paginaTitel); ?></h4>
            </div>
            <div class="card-body text-center py-4">
                <div class="mb-4">
                    <i class="fas fa-<?php echo $actie === 'goedkeuren' ? 'check-circle' : 'times-circle'; ?> fa-5x text-<?php echo $actie === 'goedkeuren' ? 'success' : 'danger'; ?> mb-3"></i>
                    <h3 class="mb-3"><?php echo htmlspecialchars($paginaTitel); ?></h3>
                    <p class="lead"><?php echo htmlspecialchars($bericht); ?></p>
                </div>
                <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                    <a href="bedrijf_verzoeken.php" class="btn btn-primary btn-lg px-4 gap-3">
                        <i class="fas fa-arrow-left me-2"></i>Terug naar overzicht
                    </a>
                </div>
            </div>
        </div>
        <?php
        generateHtmlFooter();
        exit();
        
    } else {
        // Toon bevestigingspagina
        $stmt = $conn->prepare("SELECT bv.*, b.naam AS bedrijfsnaam, g.naam AS klantnaam, g.email AS klant_email 
                               FROM bedrijf_verzoeken bv 
                               LEFT JOIN bedrijf b ON bv.bedrijf_id = b.id 
                               LEFT JOIN gebruikers g ON bv.klant_id = g.id 
                               WHERE bv.id = ?");
        $stmt->execute([$verzoekId]);
        $verzoek = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$verzoek) {
            throw new Exception('Verzoek niet gevonden');
        }
        
        $paginaTitel = 'Bevestig ' . $actieTekst . ' verzoek';
        generateHtmlHeader($paginaTitel);
        ?>
        <div class="card shadow-sm">
            <div class="card-header bg-<?php echo $actie === 'goedkeuren' ? 'warning' : 'danger'; ?> text-white">
                <h4 class="mb-0"><?php echo htmlspecialchars($paginaTitel); ?></h4>
            </div>
            <div class="card-body">
                <div class="alert alert-<?php echo $actie === 'goedkeuren' ? 'warning' : 'danger'; ?>" role="alert">
                    <h5 class="alert-heading">Let op!</h5>
                    <p class="mb-0">Weet u zeker dat u dit verzoek wilt <?php echo htmlspecialchars($actieTekst); ?>?</p>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Verzoekdetails</h5>
                    </div>
                    <div class="card-body">
                        <dl class="row">
                            <dt class="col-sm-4">Bedrijf:</dt>
                            <dd class="col-sm-8"><?php echo htmlspecialchars($verzoek['bedrijfsnaam'] ?? 'Niet opgegeven'); ?></dd>
                            
                            <dt class="col-sm-4">Aangevraagd door:</dt>
                            <dd class="col-sm-8">
                                <?php echo htmlspecialchars($verzoek['klantnaam'] ?? 'Onbekend'); ?>
                                <?php if (!empty($verzoek['klant_email'])): ?>
                                    <br><a href="mailto:<?php echo htmlspecialchars($verzoek['klant_email']); ?>">
                                        <?php echo htmlspecialchars($verzoek['klant_email']); ?>
                                    </a>
                                <?php endif; ?>
                            </dd>
                            
                            <dt class="col-sm-4">Status:</dt>
                            <dd class="col-sm-8">
                                <?php 
                                $statusClass = [
                                    'goedgekeurd' => 'success',
                                    'afgewezen' => 'danger',
                                    'in_afwachting' => 'warning',
                                    'nieuw' => 'info'
                                ][$verzoek['status']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo $statusClass; ?>">
                                    <?php echo ucfirst(htmlspecialchars($verzoek['status'])); ?>
                                </span>
                            </dd>
                            
                            <dt class="col-sm-4">Aangemaakt op:</dt>
                            <dd class="col-sm-8">
                                <?php 
                                $aangemaaktOp = new DateTime($verzoek['aangemaakt_op']);
                                echo $aangemaaktOp->format('d-m-Y H:i');
                                ?>
                            </dd>
                        </dl>
                    </div>
                </div>
                
                <form method="post" action="verwerk_verzoek.php" class="mb-0">
                    <input type="hidden" name="verzoek_id" value="<?php echo htmlspecialchars($verzoekId); ?>">
                    <input type="hidden" name="actie" value="<?php echo htmlspecialchars($actie); ?>">
                    <input type="hidden" name="bevestigd" value="ja">
                    <div class="d-flex justify-content-between">
                        <a href="bedrijf_verzoeken.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i> Annuleren
                        </a>
                        <button type="submit" class="btn btn-<?php echo $actie === 'goedkeuren' ? 'success' : 'danger'; ?>" id="bevestigKnop">
                            <i class="fas fa-<?php echo $actie === 'goedkeuren' ? 'check' : 'times'; ?> me-1"></i> 
                            <?php echo ucfirst(htmlspecialchars($actieTekst)); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php
        generateHtmlFooter();
        exit();
    }
    
} catch (Exception $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    // Toon foutpagina
    $paginaTitel = 'Fout opgetreden';
    $bericht = 'Er is een fout opgetreden: ' . $e->getMessage();
    
    generateHtmlHeader($paginaTitel);
    ?>
    <div class="card shadow-sm">
        <div class="card-header bg-danger text-white">
            <h4 class="mb-0"><?php echo htmlspecialchars($paginaTitel); ?></h4>
        </div>
        <div class="card-body text-center py-4">
            <div class="mb-4">
                <i class="fas fa-exclamation-triangle fa-5x text-danger mb-3"></i>
                <h3 class="mb-3">Er is iets misgegaan</h3>
                <p class="lead"><?php echo htmlspecialchars($bericht); ?></p>
            </div>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <a href="bedrijf_verzoeken.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left me-2"></i>Terug naar overzicht
                </a>
            </div>
        </div>
    </div>
    <?php
    generateHtmlFooter();
    exit();
}
?>
