<?php
// Database configuratie
define('DB_HOST', 'localhost');
define('DB_NAME', 'database_devops'); // Naam van je database
define('DB_USER', 'root');            // Meestal 'root' voor lokale ontwikkeling
define('DB_PASS', '');                // Wachtwoord (meestal leeg voor lokale WAMP)

try {
    // Maak een nieuwe PDO verbinding
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    // Toon een gebruiksvriendelijke foutmelding
    die("Kan geen verbinding maken met de database: " . $e->getMessage());
}
?>
