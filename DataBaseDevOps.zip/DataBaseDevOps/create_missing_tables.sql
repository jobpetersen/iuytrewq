-- Eenvoudig script om ontbrekende tabellen aan te maken
-- Stap 1: Maak de project tabel aan
CREATE TABLE IF NOT EXISTS `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_naam` varchar(255) NOT NULL,
  `beschrijving` text,
  `status` varchar(50) DEFAULT 'actief',
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_naam` (`project_naam`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Stap 2: Maak de medewerker tabel aan
CREATE TABLE IF NOT EXISTS `medewerker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `actief` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Stap 3: Voeg testgegevens toe (optioneel)
INSERT IGNORE INTO `project` (`project_naam`, `beschrijving`) VALUES
('Standaard Project', 'Algemeen project voor urenregistratie');

INSERT IGNORE INTO `medewerker` (`naam`, `email`) VALUES
('Standaard Medewerker', 'medewerker@example.com');

-- Stap 4: Controleer of de tabellen zijn aangemaakt
SHOW TABLES;
