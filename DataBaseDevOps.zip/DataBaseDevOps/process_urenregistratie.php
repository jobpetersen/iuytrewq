<?php
// Foutrapportage inschakelen
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Start de sessie
session_start();

// Zet het content type naar JSON
header('Content-Type: application/json');

// Functie om een JSON fout te retourneren
function returnJsonError($message) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

// Controleer of de database connectie beschikbaar is
if (!file_exists('db_connect.php')) {
    returnJsonError('Database configuratie bestand niet gevonden');
}

require_once 'db_connect.php';

// Controleer of er een database connectie is
if (!isset($conn)) {
    returnJsonError('Geen database verbinding');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $response = ['success' => false, 'message' => ''];
    
    try {
        // Bepaal medewerker_id en klant_id
        if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'klant') {
            $medewerker_id = 1; // Of haal het juiste ID op
            // Zoek klant_id op uit de tabel klanten
            $klantnaam = $_SESSION['naam'];
            $stmt = $conn->prepare("SELECT id FROM klanten WHERE naam = :naam LIMIT 1");
            $stmt->bindParam(':naam', $klantnaam);
            $stmt->execute();
            $klant_row = $stmt->fetch(PDO::FETCH_ASSOC);
            $klant_id = $klant_row ? $klant_row['id'] : null;
        } else {
            $medewerker_id = isset($_POST['medewerker_id']) ? $_POST['medewerker_id'] : 1;
            $klant_id = isset($_POST['klant_id']) ? $_POST['klant_id'] : null;
        }
        
        $project_id = isset($_POST['project_id']) ? $_POST['project_id'] : 1;
        $uren = isset($_POST['uren']) ? $_POST['uren'] : (isset($_POST['gewerkte_uren']) ? $_POST['gewerkte_uren'] : null);
        $datum = $_POST['datum'];
        $beschrijving = isset($_POST['beschrijving']) ? $_POST['beschrijving'] : '';
        
        if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'klant') {
            $klant = $_SESSION['naam'];
        } else {
            $klant = isset($_POST['klant']) ? $_POST['klant'] : '';
        }

        // Validate required fields
        if (empty($medewerker_id) || empty($project_id) || empty($uren) || empty($datum)) {
            throw new Exception('Vul alle verplichte velden in');
        }

        $stmt = $conn->prepare("INSERT INTO uren_registratie (medewerker_id, project_id, uren, datum, beschrijving, klant, klant_id) VALUES (:medewerker_id, :project_id, :uren, :datum, :beschrijving, :klant, :klant_id)");
        $stmt->bindParam(':medewerker_id', $medewerker_id);
        $stmt->bindParam(':project_id', $project_id);
        $stmt->bindParam(':uren', $uren);
        $stmt->bindParam(':datum', $datum);
        $stmt->bindParam(':beschrijving', $beschrijving);
        $stmt->bindParam(':klant', $klant);
        $stmt->bindParam(':klant_id', $klant_id);

        if ($stmt->execute()) {
            // Haal de nieuwe urenregistratie op om terug te sturen
            $newEntryId = $conn->lastInsertId();
            $stmt = $conn->prepare("SELECT * FROM uren_registratie WHERE id = :id");
            $stmt->bindParam(':id', $newEntryId);
            $stmt->execute();
            $newEntry = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $response['success'] = true;
            $response['message'] = 'Uren succesvol geregistreerd!';
            $response['newEntry'] = $newEntry;
        } else {
            throw new Exception('Er is een fout opgetreden bij het opslaan van de uren');
        }
    } catch(PDOException $e) {
        $response['message'] = 'Database fout: ' . $e->getMessage();
    } catch(Exception $e) {
        $response['message'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit();
}

// If not a POST request or other error
http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Ongeldig verzoek']);
?>