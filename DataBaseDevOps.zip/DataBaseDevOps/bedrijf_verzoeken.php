<?php
// bedrijf_verzoeken.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0, // Totdat browser sluit
        'path' => '/',
        'domain' => '', // localhost
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Regenerate session ID periodically to prevent session fixation
if (!isset($_SESSION['last_regen']) || time() - $_SESSION['last_regen'] > 1800) { // 30 minuten
    session_regenerate_id(true);
    $_SESSION['last_regen'] = time();
}

require_once 'db_connect.php'; // Zorg dat dit pad correct is

// Rol gebaseerde toegangscontrole
if (!isset($_SESSION['user_id']) || !isset($_SESSION['rol']) || $_SESSION['rol'] !== 'beheerder') {
    $_SESSION['error_message'] = "U heeft geen toegang tot deze pagina. Log in als beheerder.";
    header('Location: index.php'); // Stuur naar login of homepagina
    exit;
}

// Functie voor veilige output
function safeEcho($data, $default = '') {
    echo htmlspecialchars((string)($data ?? $default), ENT_QUOTES, 'UTF-8');
}

$verzoeken = [];
$error_message_db = '';

try {
    $stmt = $conn->prepare("
        SELECT 
            v.id, 
            b.naam AS bedrijfsnaam,
            g.naam AS klantnaam,
            g.email AS klant_email,
            v.status,
            v.aangemaakt_op,
            v.bedrijf_id,
            v.klant_id

        FROM bedrijf_verzoeken v
        LEFT JOIN gebruikers g ON v.klant_id = g.id
        LEFT JOIN bedrijf b ON v.bedrijf_id = b.id
        WHERE v.status IN ('in_afwachting', 'nieuw')
        ORDER BY v.aangemaakt_op DESC
    ");
    $stmt->execute();
    $verzoeken = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message_db = "Fout bij het ophalen van verzoeken: " . $e->getMessage();
    // Log de volledige fout naar een bestand of error handling systeem
    error_log("Database Fout in bedrijf_verzoeken.php: " . $e->getMessage() . "\nStack Trace: " . $e->getTraceAsString());
}

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bedrijfsverzoeken Beheren</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { 
            padding-top: 56px; /* Hoogte van de navbar */
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        .table thead th {
            background-color: #343a40;
            color: white;
        }
        .status-nieuw {
            background-color: #ffc107; /* Geel */
            color: #000;
            padding: 0.25em 0.4em;
            border-radius: 0.25rem;
            font-weight: bold;
        }
        .status-in_afwachting {
            background-color: #17a2b8; /* Cyaan */
            color: #fff;
            padding: 0.25em 0.4em;
            border-radius: 0.25rem;
            font-weight: bold;
        }
        .modal-header {
            background-color: #007bff;
            color: white;
        }
        .btn-details {
            margin-right: 5px;
        }
        .action-buttons form {
            display: inline-block;
            margin-right: 5px;
        }
        .fade-in {
            animation: fadeInAnimation ease 1s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="Home.php">Beheerder Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="bedrijf_verzoeken.php">Bedrijfsverzoeken</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="gebruikers_overzicht.php">Gebruikers</a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link" href="id_overzicht.php">ID Overzicht</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Uitloggen <i class="fas fa-sign-out-alt"></i></a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container fade-in">
    <h1 class="mb-4">Overzicht Bedrijfsverzoeken</h1>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php safeEcho($_SESSION['success_message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php safeEcho($_SESSION['error_message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <?php if ($error_message_db): ?>
        <div class="alert alert-danger" role="alert">
            <?php safeEcho($error_message_db); ?>
        </div>
    <?php endif; ?>

    <?php if (empty($verzoeken) && !$error_message_db): ?>
        <div class="alert alert-info" role="alert">
            Er zijn momenteel geen openstaande bedrijfsverzoeken.
        </div>
    <?php elseif (!empty($verzoeken)): ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Bedrijfsnaam</th>
                        <th>Klantnaam</th>
                        <th>Status</th>
                        <th>Aangevraagd Op</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($verzoeken as $verzoek): ?>
                        <tr>
                            <td><?php safeEcho($verzoek['id']); ?></td>
                            <td><?php safeEcho($verzoek['bedrijfsnaam']); ?></td>
                            <td><?php safeEcho($verzoek['klantnaam']); ?> (<?php safeEcho($verzoek['klant_email']); ?>)</td>
                            <td><span class="status-<?php safeEcho(strtolower($verzoek['status'])); ?>"><?php safeEcho(ucfirst(str_replace('_', ' ', $verzoek['status']))); ?></span></td>
                            <td><?php safeEcho(date('d-m-Y H:i', strtotime($verzoek['aangemaakt_op']))); ?></td>
                            <td class="action-buttons">
                                <button type="button" class="btn btn-info btn-sm btn-details" 
                                        data-bs-toggle="modal" data-bs-target="#detailsModal"
                                        data-verzoek-id="<?php safeEcho($verzoek['id']); ?>"
                                        data-bedrijfsnaam="<?php safeEcho($verzoek['bedrijfsnaam']); ?>"
                                        data-klantnaam="<?php safeEcho($verzoek['klantnaam']); ?>"
                                        data-klant-email="<?php safeEcho($verzoek['klant_email']); ?>"
                                        data-status="<?php safeEcho($verzoek['status']); ?>"
                                        data-aangemaakt="<?php safeEcho(date('d-m-Y H:i', strtotime($verzoek['aangemaakt_op']))); ?>"
>
                                    <i class="fas fa-eye"></i> Details
                                </button>
                                <form action="verwerk_verzoek.php" method="post" class="needs-validation" novalidate>
                                    <input type="hidden" name="verzoek_id" value="<?php safeEcho($verzoek['id']); ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : ''; ?>">
                                    <button type="submit" data-action="goedkeuren" class="btn btn-success btn-sm submit-button">
                                        <i class="fas fa-check"></i> Goedkeuren
                                    </button>
                                    <button type="submit" data-action="afwijzen" class="btn btn-danger btn-sm submit-button">
                                        <i class="fas fa-times"></i> Afwijzen
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailsModalLabel">Details Bedrijfsverzoek</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Verzoek ID:</strong> <span id="modal-verzoek-id"></span></p>
                <p><strong>Bedrijfsnaam:</strong> <span id="modal-bedrijfsnaam"></span></p>
                <p><strong>Klantnaam:</strong> <span id="modal-klantnaam"></span></p>
                <p><strong>Klant E-mail:</strong> <span id="modal-klant-email"></span></p>
                <p><strong>Status:</strong> <span id="modal-status"></span></p>
                <p><strong>Aangevraagd op:</strong> <span id="modal-aangemaakt"></span></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluiten</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Tooltips initialiseren (indien nodig, voeg data-bs-toggle="tooltip" toe aan elementen)
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Details Modal vullen
        var detailsModal = document.getElementById('detailsModal');
        if (detailsModal) {
            detailsModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                
                document.getElementById('modal-verzoek-id').textContent = button.getAttribute('data-verzoek-id');
                document.getElementById('modal-bedrijfsnaam').textContent = button.getAttribute('data-bedrijfsnaam');
                document.getElementById('modal-klantnaam').textContent = button.getAttribute('data-klantnaam');
                document.getElementById('modal-klant-email').textContent = button.getAttribute('data-klant-email');
                
                var status = button.getAttribute('data-status');
                var statusSpan = document.getElementById('modal-status');
                statusSpan.textContent = status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ');
                statusSpan.className = 'status-' + status.toLowerCase();

                document.getElementById('modal-aangemaakt').textContent = button.getAttribute('data-aangemaakt');

            });
        }

        // Voorkom dubbele formulierinzendingen en stel actie in
        var forms = document.querySelectorAll('form.needs-validation'); // Wees specifieker met de selector
        forms.forEach(function(form) {
            // Listener voor de knoppen zelf om de actie te bepalen
            var actionButtons = form.querySelectorAll('.submit-button[data-action]');
            actionButtons.forEach(function(actionButton) {
                actionButton.addEventListener('click', function(clickEvent) {
                    // Verwijder eventueel bestaand actieveld om duplicaten te voorkomen als de gebruiker snel wisselt
                    var existingActionInput = form.querySelector('input[name="actie"]');
                    if (existingActionInput) {
                        existingActionInput.remove();
                    }
                    // Voeg nieuw actieveld toe
                    var actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'actie';
                    actionInput.value = this.getAttribute('data-action');
                    form.appendChild(actionInput);
                });
            });

            form.addEventListener('submit', function(event) {
                var submitButtonsInForm = form.querySelectorAll('.submit-button'); // Knoppen binnen dit specifieke formulier
                submitButtonsInForm.forEach(function(button) {
                    button.disabled = true;
                    button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verwerken...'; 
                });
            });
        });

        // Automatisch sluiten van alerts na 5 seconden
        var alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function(alert) {
            setTimeout(function() {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 5000);
        });
    });
</script>

</body>
</html>
