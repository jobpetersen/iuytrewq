<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $stmt = $conn->prepare("SELECT * FROM gebruikers WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['wachtwoord'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['naam'] = $user['naam'];
            $_SESSION['rol'] = $user['rol'];
            $_SESSION['bedrijfsnaam'] = isset($user['bedrijfsnaam']) ? $user['bedrijfsnaam'] : '';
            header("Location: Home.php");
            exit();
        } else {
            header("Location: index.php?error=invalid");
            exit();
        }
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?> 