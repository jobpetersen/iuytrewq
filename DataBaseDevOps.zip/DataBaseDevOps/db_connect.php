<?php
/**
 * Database verbinding
 * 
 * Dit script regelt de verbinding met de bestaande database.
 */

// Start de sessie indien nodig
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Foutrapportage inschakelen
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
$errorLogFile = __DIR__ . '/php_errors.log';
ini_set('error_log', $errorLogFile);

// Controleer of de error log beschrijfbaar is
if (!is_writable($errorLogFile) && !is_writable(dirname($errorLogFile))) {
    die('Error log bestand is niet beschrijfbaar. Controleer de permissies van ' . $errorLogFile);
}

// Controleer of de PDO MySQL extensie is ingeschakeld
if (!extension_loaded('pdo_mysql')) {
    $error = 'PDO MySQL extensie is niet ingeschakeld in PHP. Controleer uw PHP configuratie.';
    error_log($error);
    die('Fout: ' . $error);
}

// Database configuratie
$config = [
    'host' => '127.0.0.1',  // Gebruik IP in plaats van localhost
    'username' => 'root',
    'password' => '',
    'dbname' => 'database_devops',
    'charset' => 'utf8mb4',
    'port' => 3306
];

/**
 * Maakt een PDO databaseverbinding aan
 * 
 * @param array $config Database configuratie
 * @return PDO De database verbinding
 * @throws PDOException Als de verbinding mislukt
 */
function getDatabaseConnection($config) {
    try {
        // Probeer eerst met de database naam
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
        error_log("Poging om verbinding te maken met database: {$config['dbname']} op {$config['host']}");
        
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::ATTR_TIMEOUT => 5, // Timeout na 5 seconden
            PDO::ATTR_PERSISTENT => false
        ];
        
        $conn = new PDO($dsn, $config['username'], $config['password'], $options);
        error_log("Database verbinding succesvol!");
        return $conn;
        
    } catch (PDOException $e) {
        // Log de fout
        $errorMsg = 'Database fout: ' . $e->getMessage() . "\n";
        $errorMsg .= 'Bestand: ' . $e->getFile() . ' (Regel: ' . $e->getLine() . ")\n";
        $errorMsg .= 'DSN: ' . ($dsn ?? 'niet ingesteld') . "\n";
        error_log($errorMsg);
        
        // Toon eenvoudige foutmelding aan de gebruiker
        die('Er is een fout opgetreden bij het verbinden met de database. Probeer het later opnieuw.');
    }
}

// Maak een databaseverbinding beschikbaar
$conn = getDatabaseConnection($config);