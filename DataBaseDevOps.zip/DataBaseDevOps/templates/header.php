<?php 
// Zorg ervoor dat db_connect.php al is geïncludeerd op de hoofdpagina voordat deze header wordt geladen,
// of uncomment de volgende regel als je het hier wilt doen (pas op voor multiple includes/session_start errors).
// require_once __DIR__ . '/../db_connect.php'; 

// Dynamische titel, kan op elke pagina worden overschreven
if (!isset($page_title)) {
    $page_title = 'DataBase DevOps';
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo isset($base_url) ? $base_url : ''; ?>css/style.css">
    <style>
        body {
            padding-top: 70px; /* Ruimte voor fixed-top navbar */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .content-wrapper {
            flex: 1;
        }
        .user-info-header {
            position: fixed;
            top: 10px;
            right: 20px;
            z-index: 1050; /* Hoger dan navbar */
            background-color: rgba(255,255,255,0.8);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
        }
        .navbar {
            background-color: #f8f9fa; /* Lichte achtergrond voor de navbar */
        }
        .logo {
            max-height: 50px;
        }
    </style>
</head>
<body>

<?php if (isset($_SESSION['user_id']) && isset($_SESSION['email'])): ?>
<div class="user-info-header">
    Ingelogd als: <strong><?php echo htmlspecialchars($_SESSION['email']); ?></strong>
</div>
<?php endif; ?>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo isset($base_url) ? $base_url : ''; ?>Home.php">
            <img src="<?php echo isset($base_url) ? $base_url : ''; ?>Images/logo.png" alt="Logo" class="logo">
            DataBase DevOps
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo isset($base_url) ? $base_url : ''; ?>Home.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>Contact.php">Contact</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'beheerder'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>bedrijf_verzoeken.php">Bedrijf Verzoeken</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>gebruikers_overzicht.php">Gebruikers</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>logout.php">Log Uit</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>inloggen.php">Log In</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo isset($base_url) ? $base_url : ''; ?>registreren.php">Registreren</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container content-wrapper mt-4 mb-4">
    <?php 
    // Flash messages display (Bootstrap alerts)
    if (isset($_SESSION['success_message'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">'
             . htmlspecialchars($_SESSION['success_message'])
             . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">'
             . htmlspecialchars($_SESSION['error_message'])
             . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['error_message']);
    }
    if (isset($_SESSION['info_message'])) {
        echo '<div class="alert alert-info alert-dismissible fade show" role="alert">'
             . htmlspecialchars($_SESSION['info_message'])
             . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['info_message']);
    }
    // General flash message (used in Home.php for company request)
    if (isset($_SESSION['flash_message'])) {
        echo '<div class="alert alert-info alert-dismissible fade show" role="alert">'
             . $_SESSION['flash_message'] // Assuming flash_message might contain HTML like <b> tags
             . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['flash_message']);
    }
    ?>
