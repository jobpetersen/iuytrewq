<?php
// klanten_overzicht.php
// Overzicht van alle gebruikers

// Start de sessie
session_start();

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Controleer of de gebruiker de rol 'beheerder' heeft
if ($_SESSION['rol'] !== 'beheerder') {
    header('Location: Home.php');
    exit;
}

require_once 'db_connect.php';

// Haal alle gebruikers op
$stmt = $conn->query("SELECT id, naam, email, rol, aangemaakt_op FROM gebruikers ORDER BY id");
$gebruikers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gebruikers Overzicht</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { padding: 20px; }
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .btn-add-user {
            margin-left: 10px;
        }
        .table-responsive {
            margin-bottom: 40px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 5px;
            overflow: hidden;
        }
        .table th {
            background-color: #343a40;
            color: white;
            border-color: #454d55;
        }
        .table td {
            vertical-align: middle;
        }
        .badge {
            font-size: 0.9em;
            padding: 5px 10px;
        }
        .badge-admin {
            background-color: #6f42c1;
        }
        .badge-medewerker {
            background-color: #007bff;
        }
        .badge-klant {
            background-color: #28a745;
        }
        .badge-beheerder {
            background-color: #6f42c1; /* Paarse achtergrond zoals .badge-admin */
            color: #000000 !important; /* Zwarte tekstkleur */
        }
        .action-buttons .btn {
            margin-right: 5px;
            padding: 3px 8px;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-container">
            <h1><i class="fas fa-users"></i> Gebruikers Overzicht</h1>
            <div>
                <a href="Home.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Terug naar Home
                </a>
                <a href="gebruiker_toevoegen.php" class="btn btn-success btn-add-user">
                    <i class="fas fa-user-plus"></i> Nieuwe Gebruiker
                </a>
            </div>
        </div>
        <?php if (count($gebruikers) > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Naam</th>
                        <th>E-mail</th>
                        <th>Rol</th>
                        <th>Aangemaakt op</th>
                        <th>Acties</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($gebruikers as $gebruiker): 
                        $badgeClass = 'badge-' . strtolower($gebruiker['rol']);
                        $formattedDate = date('d-m-Y H:i', strtotime($gebruiker['aangemaakt_op']));
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($gebruiker['id']); ?></td>
                        <td><?php echo htmlspecialchars($gebruiker['naam']); ?></td>
                        <td><?php echo htmlspecialchars($gebruiker['email']); ?></td>
                        <td>
                            <span class="badge <?php echo $badgeClass; ?>">
                                <?php echo ucfirst(htmlspecialchars($gebruiker['rol'])); ?>
                            </span>
                        </td>
                        <td><?php echo $formattedDate; ?></td>
                        <td class="action-buttons">
                            <a href="gebruiker_toevoegen.php?edit=<?php echo $gebruiker['id']; ?>" 
                               class="btn btn-sm btn-primary" title="Bewerken">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button onclick="confirmDelete(<?php echo $gebruiker['id']; ?>, '<?php echo htmlspecialchars(addslashes($gebruiker['naam'])); ?>')" 
                                    class="btn btn-sm btn-danger" title="Verwijderen">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
            <div class="alert alert-info">
                Er zijn nog geen gebruikers gevonden. <a href="gebruiker_toevoegen.php" class="alert-link">Voeg de eerste gebruiker toe</a>.
            </div>
        <?php endif; ?>
    </div>

    <!-- Bevestigingsmodal voor verwijderen -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Bevestig verwijderen</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Sluiten">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Weet je zeker dat je gebruiker <strong id="userToDelete"></strong> wilt verwijderen?
                    <p class="text-muted mt-2"><small>Deze actie kan niet ongedaan worden gemaakt.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuleren</button>
                    <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Verwijderen</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        function confirmDelete(userId, userName) {
            document.getElementById('userToDelete').textContent = userName;
            const deleteBtn = document.getElementById('confirmDeleteBtn');
            deleteBtn.href = `gebruiker_verwijderen.php?id=${userId}`;
            
            $('#deleteModal').modal('show');
        }
        
        // Toon eventuele foutmeldingen in de URL
        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                alert(urlParams.get('success'));
            } else if (urlParams.has('error')) {
                alert('Fout: ' + urlParams.get('error'));
            }
        });
    </script>
</body>
</html>