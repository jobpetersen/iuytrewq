<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <img src="Images/logo.png" alt="Logo" class="logo">
        <div class="nav-links">
            <a href="Home.php">Home</a>
            <a href="Contact.php">Contact</a>
        </div>
    </nav>
    <div class="login-container">
        <h2 class="login-title">Login</h2>
        <?php
        if (isset($_GET['error'])) {
            if ($_GET['error'] == 'invalid') {
                echo '<div class="error-message">Invalid email or password</div>';
            }
        }
        ?>
        <form action="process_login.php" method="POST">
            <div class="input-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Wachtwoord" required>
            </div>
            <button type="submit" class="login-button">Login</button>
        </form>
    </div>
</body>
</html>
